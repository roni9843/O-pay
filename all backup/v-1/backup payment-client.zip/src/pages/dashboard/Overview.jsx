import React from "react";
import { Link } from "react-router-dom";
import { useAuthStore } from "../../store/authStore";
import api from "../../lib/api";
import {
  ArrowUpRight,
  Activity,
  DollarSign,
  Clock,
  Smartphone,
  Globe,
  CheckCircle,
  AlertCircle,
  Sparkles,
  CreditCard,
  LayoutDashboard,
  User,
  Wallet,
  Zap,
  ClipboardList,
  Wifi,
  PhoneCall,
} from "lucide-react";
import opayLogo from "../../assets/appstore.png";

function formatAmount(value) {
  if (value == null) return "0.00";
  return Number(value).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatDate(value) {
  if (!value) return "—";
  return new Date(value).toLocaleString("en-US", { 
    month: "short", 
    day: "numeric", 
    hour: "2-digit", 
    minute: "2-digit" 
  });
}

export default function Overview() {
  const token = useAuthStore((s) => s.token);
  const user = useAuthStore((s) => s.user);
  const [stats, setStats] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);
  const [walletSubEnd, setWalletSubEnd] = React.useState(null);
  const [walletSubActive, setWalletSubActive] = React.useState(false);

  React.useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        setLoading(true);
        const res = await api.getDashboardOverview(token);
        if (!cancelled) {
          setStats(res?.data || {
            totals: { totalTransactions: 0, totalAmount: 0 },
            today: { totalTransactions: 0, totalAmount: 0 },
            devices: [],
            providers: [],
            recent: [],
          });
        }
      } catch (err) {
        if (!cancelled) setError(err?.message || "Failed to load dashboard");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    if (token) load();
    return () => { cancelled = true; };
  }, [token]);

  // Load current subscription end date for wallet agents (for "Valid Thru")
  React.useEffect(() => {
    if (!token || user?.role !== "wallet_agent") return;
    let cancelled = false;

    async function loadWalletSubscription() {
      try {
        const subs = await api.getMySubscriptions(token);
        if (cancelled) return;
        if (!Array.isArray(subs) || subs.length === 0) {
          setWalletSubEnd(null);
          setWalletSubActive(false);
          return;
        }
        const active = subs.filter((s) => s.active);
        const list = active.length ? active : subs;
        const sorted = [...list].sort((a, b) => new Date(b.endDate) - new Date(a.endDate));
        const latest = sorted[0];
        setWalletSubEnd(latest?.endDate || null);
        setWalletSubActive(Boolean(latest?.active));
      } catch (_) {
        if (!cancelled) {
          setWalletSubEnd(null);
          setWalletSubActive(false);
        }
      }
    }

    loadWalletSubscription();
    return () => {
      cancelled = true;
    };
  }, [token, user?.role]);

  if (!token) return null;

 // Specialized dashboard UI for wallet agents (green banking-style layout)
if (user?.role === "wallet_agent") {
  const emailLine = user?.email || "agent@example.com";
  const validThru = (() => {
    if (!walletSubEnd) return "MM/YY";
    const d = new Date(walletSubEnd);
    if (Number.isNaN(d.getTime())) return "MM/YY";
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const yy = String(d.getFullYear()).slice(-2);
    return `${mm}/${yy}`;
  })();
  const creditAmount = formatAmount(user?.credit ?? 0);
  const statusLabel = walletSubActive ? "Active" : "Inactive";
  const shortcutItems = [
    { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/dashboard/profile", label: "Profile", icon: User },
    { to: "/dashboard/payment", label: "Payment", icon: CreditCard },
    { to: "/dashboard/add-balance", label: "Add Balance", icon: Wallet },
    { to: "/dashboard/pending-balance", label: "Pending Balance", icon: Clock },
    { to: "/dashboard/subscription", label: "Subscription", icon: Zap },
    { to: "/dashboard/your-plan", label: "Your Plan", icon: ClipboardList },
    { to: "/dashboard/device", label: "Device", icon: Smartphone },
    { to: "/dashboard/devices-presence", label: "Devices Presence", icon: Wifi },
    { to: "/dashboard/add-payment-method", label: "Add Payment Method", icon: CreditCard },
    { to: "/dashboard/number-status", label: "Number Status", icon: PhoneCall },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-emerald-100 flex flex-col items-center px-4 sm:px-6 py-8 md:py-12">
      <div className="w-full max-w-md lg:max-w-lg space-y-8 md:space-y-10">

        {/* ── Realistic & Compact Bank Card ── */}
        <div className="relative w-full aspect-[1.585/1] max-w-[360px] mx-auto rounded-3xl overflow-hidden shadow-2xl transform hover:scale-[1.015] transition-transform duration-400">
          {/* Background + subtle geometric overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-700 via-teal-600 to-emerald-800">
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(circle_at_15%_25%,rgba(255,255,255,0.14)_0%,transparent_45%),radial-gradient(circle_at_85%_75%,rgba(255,255,255,0.10)_0%,transparent_55%)]" />
          </div>

          {/* Glossy shine */}
          <div className="absolute inset-0 bg-gradient-to-t from-transparent via-white/12 to-transparent opacity-70 pointer-events-none" />

          <div className="relative h-full px-5 sm:px-7 pt-5 sm:pt-7 pb-6 sm:pb-8 text-white flex flex-col">
            {/* Header: Bank name + logo */}
            <div className="flex items-center justify-between mb-4 sm:mb-5">
              <div className="flex items-center gap-2.5 sm:gap-3">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-white/90 flex items-center justify-center shadow-inner overflow-hidden">
                  {/* Replace with your actual logo import */}
                  {/* <img src={opayLogo} alt="Opay" className="w-7 h-7 sm:w-8 sm:h-8 object-contain" /> */}
                  <span className="text-xl font-bold text-emerald-800">O</span>
                </div>
                <div>
                  <p className="text-sm sm:text-base font-semibold tracking-wide">Opay Digital Bank</p>
                  <p className="text-xs opacity-85 -mt-0.5">Agent Wallet</p>
                </div>
              </div>
              <div className="text-2xl sm:text-3xl opacity-90">  <div className="w-10 h-8 sm:w-12 sm:h-9 bg-gradient-to-br from-amber-300 via-yellow-400 to-amber-400 rounded shadow-inner flex items-center justify-center">
                <div className="w-6 h-4.5 sm:w-7 sm:h-5 bg-gradient-to-br from-amber-100 to-amber-300 rounded shadow-sm" />
              </div></div>
            </div>

     

            {/* Name + Expiry – reduced sizes */}
            <div className="flex justify-between items-end mb-4 sm:mb-5 flex-1">
              <div>
                <p className="text-xs uppercase opacity-80 tracking-wider mb-0.5">Cardholder</p>
                <p className="text-base sm:text-lg font-medium tracking-wide">
                  {user?.name?.toUpperCase() || "AGENT NAME"}
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs uppercase opacity-80 tracking-wider mb-0.5">Valid Thru</p>
                <p className="text-base sm:text-lg font-mono">{validThru}</p>
              </div>
            </div>

            {/* Balance section – compact */}
            <div className="pt-3 sm:pt-4 border-t border-white/30">
              <p className="text-xs uppercase tracking-wider opacity-80 mb-0.5">Available Balance</p>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl sm:text-2xl font-bold">BDT</span>
                <span className="text-2xl sm:text-3xl font-black tracking-tight">{creditAmount}</span>
              </div>
            </div>

            {/* Status badge – smaller & positioned tighter */}
            <div className="absolute bottom-3 right-3 sm:bottom-4 sm:right-4">
              <div className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1 bg-white/25 backdrop-blur-lg rounded-full text-xs font-medium shadow-inner">
                <div className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
                {statusLabel}
              </div>
            </div>
          </div>
        </div>

        {/* Quick Services – unchanged but fits well below compact card */}
        <div className="bg-white/75 backdrop-blur-lg rounded-3xl shadow-xl p-5 sm:p-6 md:p-8 border border-emerald-100/70">
          <h3 className="text-lg sm:text-xl font-semibold text-emerald-900 mb-5 sm:mb-6">Quick Services</h3>
          <div className="grid grid-cols-4 gap-3 sm:gap-4 md:gap-5 text-center">
            {[
              { label: "Own A/C", icon: "🏦" },
              { label: "AIB Transfer", icon: "↔️" },
              { label: "Other Bank", icon: "🌐" },
              { label: "Bangla QR", icon: "□" },
              { label: "Add Money", icon: "💰" },
              { label: "bKash", icon: "📱" },
              { label: "Beneficiary", icon: "👤" },
              { label: "More", icon: "⋯" },
            ].map((item) => (
              <button
                key={item.label}
                className="flex flex-col items-center gap-1.5 sm:gap-2 py-3 sm:py-4 px-1 rounded-2xl hover:bg-emerald-50/80 active:bg-emerald-100 transition-all group touch-manipulation"
              >
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-emerald-100 to-teal-100 text-emerald-800 flex items-center justify-center text-2xl sm:text-3xl shadow group-hover:scale-105 transition-transform">
                  {item.icon}
                </div>
                <span className="text-xs sm:text-sm font-medium text-gray-800 leading-tight">
                  {item.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Dashboard Shortcuts from sidebar */}
        <div className="bg-white/80 backdrop-blur-lg rounded-3xl shadow-xl p-5 sm:p-6 md:p-8 border border-emerald-100/70">
          <h3 className="text-lg sm:text-xl font-semibold text-emerald-900 mb-4 sm:mb-5">Dashboard Menu</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
            {shortcutItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className="flex flex-col items-start gap-2 px-3 py-3 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-100 transition-all shadow-sm hover:shadow-md"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-xs sm:text-sm font-medium leading-snug">
                    {item.label}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white p-6 overflow-hidden relative">
      {/* Animated Background Blobs */}
      <div className="fixed inset-0 pointer-events-none opacity-30">
        <div className="absolute top-10 left-20 w-96 h-96 bg-purple-600 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div className="absolute top-40 right-10 w-80 h-80 bg-pink-600 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-20 left-1/3 w-72 h-72 bg-cyan-600 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-4000"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-12 mt-8">
          <h1 className="text-6xl font-black bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent animate-pulse-slow">
            Dashboard Overview
          </h1>
          <p className="text-purple-300 text-lg mt-4 flex items-center justify-center gap-3">
            <Sparkles className="w-5 h-5 animate-twinkle" />
            Real-time payment intelligence at your fingertips
            <Sparkles className="w-5 h-5 animate-twinkle" />
          </p>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-36 rounded-3xl bg-white/5 backdrop-blur-xl border border-white/10 animate-pulse" />
            ))}
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="p-6 rounded-3xl bg-rose-500/20 border border-rose-500/50 backdrop-blur-xl text-rose-300 text-center font-medium">
            {error}
          </div>
        )}

        {/* Main Content */}
        {!loading && !error && stats && (
          <>
            {/* Stats Cards - Premium Glassmorphism */}
            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4 mb-10">
              {[
                { label: "Total Transactions", value: stats.totals.totalTransactions, icon: Activity, color: "from-purple-500 to-pink-500" },
                { label: "Total Volume", value: `৳${formatAmount(stats.totals.totalAmount)}`, icon: DollarSign, color: "from-emerald-500 to-teal-500" },
                { label: "Today's Transactions", value: stats.today.totalTransactions, icon: ArrowUpRight, color: "from-orange-500 to-pink-500" },
                { label: "Today's Volume", value: `৳${formatAmount(stats.today.totalAmount)}`, icon: Globe, color: "from-cyan-500 to-blue-500" },
              ].map((stat, idx) => (
                <div
                  key={idx}
                  className="relative overflow-hidden rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-2xl hover:shadow-purple-500/30 transform hover:scale-105 transition-all duration-500 group"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-20 group-hover:opacity-40 transition-opacity`} />
                  <div className="relative p-8">
                    <div className="flex items-center justify-between mb-4">
                      <stat.icon className="w-10 h-10 text-white/80" />
                      <Sparkles className="w-6 h-6 text-yellow-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <p className="text-sm text-purple-300 uppercase tracking-wider">{stat.label}</p>
                    <p className="text-4xl font-bold mt-3 bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
                      {stat.value}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid gap-8 lg:grid-cols-3">
              {/* Recent Transactions */}
              <div className="lg:col-span-2 rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-2xl overflow-hidden">
                <div className="p-8 border-b border-white/10">
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                    Recent Transactions
                  </h3>
                  <p className="text-purple-300 text-sm mt-1">Latest incoming payments</p>
                </div>
                <div className="overflow-x-auto">
                  {stats.recent.length === 0 ? (
                    <div className="p-12 text-center text-purple-300">
                      <Clock className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>No transactions yet. Waiting for first payment...</p>
                    </div>
                  ) : (
                    <table className="w-full">
                      <thead>
                        <tr className="text-left text-xs uppercase tracking-wider text-purple-300 border-b border-white/10">
                          <th className="pb-4 pl-8">TrxID</th>
                          <th className="pb-4">Amount</th>
                          <th className="pb-4">Provider</th>
                          <th className="pb-4">Device</th>
                          <th className="pb-4">Time</th>
                          <th className="pb-4 pr-8">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {stats.recent.map((item, i) => (
                          <tr key={i} className="border-b border-white/5 hover:bg-white/5 transition">
                            <td className="py-5 pl-8 font-mono text-sm">{item.trxID}</td>
                            <td className="py-5 font-bold text-emerald-400">৳{formatAmount(item.amount)}</td>
                            <td className="py-5 text-purple-300">{item.title || "Unknown"}</td>
                            <td className="py-5 text-cyan-300">{item.deviceName || "—"}</td>
                            <td className="py-5 text-sm text-purple-200">{formatDate(item.createdAt)}</td>
                            <td className="py-5 pr-8">
                              {item.verify ? (
                                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-medium">
                                  <CheckCircle className="w-4 h-4" /> Verified
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/20 text-amber-300 text-xs font-medium">
                                  <AlertCircle className="w-4 h-4" /> Pending
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>

              {/* Right Sidebar */}
              <div className="space-y-6">
                {/* Devices */}
                <div className="rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-2xl p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <Smartphone className="w-8 h-8 text-cyan-400" />
                    <h3 className="text-xl font-bold">Active Devices</h3>
                  </div>
                  {stats.devices.length === 0 ? (
                    <p className="text-purple-300 text-sm">No devices connected</p>
                  ) : (
                    <div className="space-y-4">
                      {stats.devices.slice(0, 4).map((d) => (
                        <div key={d.deviceId} className="p-4 rounded-2xl bg-white/5 border border-white/10">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-semibold text-purple-200">{d.deviceName}</p>
                              <p className="text-xs text-purple-400">{d.deviceCode || d.deviceId}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-emerald-400">৳{formatAmount(d.totalAmount)}</p>
                              <p className="text-xs text-purple-300">{d.totalTransactions} trx</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Providers */}
                <div className="rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-2xl p-8">
                  <h3 className="text-xl font-bold mb-6 flex items-center gap-3">
                    <Globe className="w-8 h-8 text-pink-400" />
                    Top Providers
                  </h3>
                  {stats.providers.length === 0 ? (
                    <p className="text-purple-300 text-sm">No data available</p>
                  ) : (
                    <div className="space-y-4">
                      {stats.providers.slice(0, 4).map((p, i) => (
                        <div key={i} className="flex justify-between items-center">
                          <span className="text-purple-200 font-medium">{p.provider}</span>
                          <div className="text-right">
                            <p className="font-bold text-cyan-400">৳{formatAmount(p.totalAmount)}</p>
                            <p className="text-xs text-purple-300">{p.totalTransactions} trx</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Wallet Agent Credit Summary */}
                {user?.role === "wallet_agent" && (
                  <div className="rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-2xl p-8">
                    <div className="flex items-center gap-3 mb-4">
                      <CreditCard className="w-8 h-8 text-indigo-400" />
                      <div>
                        <h3 className="text-xl font-bold">Wallet Credit</h3>
                        <p className="text-purple-300 text-sm">Your available wallet agent credit</p>
                      </div>
                    </div>
                    <div className="text-3xl font-bold bg-gradient-to-r from-white to-indigo-200 bg-clip-text text-transparent">
                      ৳{formatAmount(user?.credit ?? 0)}
                    </div>
                    <p className="mt-2 text-xs text-purple-200">
                      This credit is separate from your main balance and is used for wallet agent operations.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>

      {/* Custom Animations */}
      <style jsx>{`
        @keyframes blob {
          0%, 100% { transform: translate(0px, 0px) scale(1); }
          50% { transform: translate(30px, -30px) scale(1.1); }
        }
        .animate-blob { animation: blob 20s infinite; }
        .animation-delay-2000 { animation-delay: 2s; }
        .animation-delay-4000 { animation-delay: 4s; }
        .animate-twinkle { animation: twinkle 2s infinite alternate; }
        @keyframes twinkle { from { opacity: 0.5; } to { opacity: 1; } }
        .animate-pulse-slow { animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
      `}</style>
    </div>
  );
}