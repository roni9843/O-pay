import React from "react";
import { useAuthStore } from "../../store/authStore";
import api from "../../lib/api";
import { Wallet, CheckCircle, XCircle, Loader2, Sun, Moon, Image as ImageIcon } from "lucide-react";

export default function AddBalance() {
  const token = useAuthStore((s) => s.token);
  const user = useAuthStore((s) => s.user);
  const setUser = useAuthStore((s) => s.setUser);

  const [amount, setAmount] = React.useState(25);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [success, setSuccess] = React.useState(null);
  const [darkMode, setDarkMode] = React.useState(true);
  const [file, setFile] = React.useState(null);
  const [fileError, setFileError] = React.useState(null);
  const [binanceAddress, setBinanceAddress] = React.useState('');
  const [copied, setCopied] = React.useState(false);

  const quick = [25, 50, 100, 500, 1000];

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setFileError(null);
    const num = Number(amount);
    if (isNaN(num) || num < 25) {
      setError("Minimum amount is $25");
      return;
    }
    if (!file) {
      setFileError("Please upload your Binance transaction screenshot");
      return;
    }
    setLoading(true);
    try {
      const form = new FormData();
      form.append('amount', String(num));
      form.append('screenshot', file);
      const res = await fetch(`${import.meta.env.VITE_API_URL || 'https://api.oraclepay.org'}/api/balance-topups`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: form,
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) throw new Error((data && data.message) || 'Failed to submit');
      setSuccess('Submitted for approval. Status: pending');
      setTimeout(() => setSuccess(null), 4000);
    } catch (err) {
      setError(err.message || "Failed to add balance");
      setTimeout(() => setError(null), 4000);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    async function fetchAddress(){
      try {
        const res = await fetch(`${import.meta.env.VITE_API_URL || 'https://api.oraclepay.org'}/api/settings/binance-address`);
        const data = await res.json();
        if (res.ok) setBinanceAddress(data.address || '');
      } catch (_) {}
    }
    fetchAddress();
  }, []);

  // Dark mode classes
  const bgClass = darkMode ? "bg-gray-900" : "bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50";
  const cardClass = darkMode
    ? "bg-gray-800/90 backdrop-blur-2xl border border-gray-700"
    : "bg-white/95 backdrop-blur-2xl border border-white/30";

  return (
    <div className={`min-h-screen ${bgClass} flex items-center justify-center p-4 transition-colors duration-300`}>
      {/* Dark Mode Toggle - Top Right */}
      <button
        onClick={() => setDarkMode(!darkMode)}
        className={`fixed top-6 right-6 p-3 rounded-full shadow-lg transition-all z-10 ${
          darkMode ? "bg-gray-700 hover:bg-gray-600" : "bg-white hover:bg-gray-100"
        }`}
      >
        {darkMode ? <Sun className="w-5 h-5 text-yellow-400" /> : <Moon className="w-5 h-5 text-indigo-600" />}
      </button>

      <div className="relative w-full max-w-md">
        {/* Gradient Border */}
        <div className={`absolute -inset-1 rounded-3xl blur-xl opacity-70 animate-pulse ${
          darkMode
            ? "bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-600"
            : "bg-gradient-to-r from-violet-600 via-pink-600 to-cyan-600"
        }`}></div>

        {/* Compact Card */}
        <div className={`relative ${cardClass} rounded-3xl shadow-2xl p-6`}>
          
          {/* Header */}
          <div className="text-center mb-6">
            <div className={`inline-flex items-center justify-center w-14 h-14 rounded-2xl mb-3 shadow-lg ${
              darkMode ? "bg-gradient-to-br from-emerald-500 to-teal-600" : "bg-gradient-to-br from-emerald-500 to-teal-600"
            }`}>
              <Wallet className="w-8 h-8 text-white" />
            </div>
            <h2 className={`text-2xl font-bold ${
              darkMode ? "text-white" : "bg-gradient-to-r from-violet-600 to-pink-600 bg-clip-text text-transparent"
            }`}>
              Add Balance
            </h2>
          </div>

          {/* Current Balance */}
          <div className={`mb-6 p-4 rounded-2xl shadow-lg text-white ${
            darkMode ? "bg-gradient-to-r from-emerald-600 to-teal-700" : "bg-gradient-to-r from-emerald-500 to-teal-600"
          }`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs opacity-90">Current Balance</p>
                <p className="text-2xl font-bold">${user?.balance?.toFixed(2) || "0.00"}</p>
              </div>
            </div>
          </div>

          {/* Quick Select */}
          <div className="mb-5">
            <p className={`text-sm font-medium mb-2 ${darkMode ? "text-gray-300" : "text-gray-700"}`}>Quick Select</p>
            <div className="grid grid-cols-3 gap-2">
              {quick.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setAmount(q)}
                  className={`relative overflow-hidden rounded-xl p-3 font-bold text-sm transition-all duration-200 transform hover:scale-105
                    ${Number(amount) === q
                      ? darkMode
                        ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg"
                        : "bg-gradient-to-r from-violet-500 to-pink-500 text-white shadow-lg"
                      : darkMode
                      ? "bg-gray-700 text-gray-300 hover:bg-gray-600"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                >
                  ${q}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Amount */}
          <div className="mb-5">
            <label className={`block text-sm font-medium mb-1.5 ${darkMode ? "text-gray-300" : "text-gray-700"}`}>
              Custom Amount
            </label>
            <div className="relative">
              <span className={`absolute left-4 top-1/2 -translate-y-1/2 text-lg ${darkMode ? "text-gray-400" : "text-gray-500"}`}>
                $
              </span>
              <input
                type="number"
                min="25"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`w-full pl-10 pr-4 py-3 rounded-xl border-2 text-base font-medium transition-all
                  ${darkMode
                    ? "bg-gray-700 border-gray-600 text-white focus:border-purple-500 focus:ring-4 focus:ring-purple-500/20"
                    : "bg-white border-gray-300 text-gray-900 focus:border-violet-500 focus:ring-4 focus:ring-violet-500/20"
                  }`}
                placeholder="25"
              />
            </div>
            <p className={`text-xs mt-1.5 ${darkMode ? "text-gray-400" : "text-gray-500"}`}>Minimum $25</p>
          </div>

          {/* Binance Address + Screenshot Upload */}
          <div className="mb-5">
            <label className={`block text-sm font-medium mb-1.5 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Binance Address
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={binanceAddress || ''}
                className={`flex-1 px-3 py-2 rounded-xl border ${darkMode ? 'bg-gray-700 border-gray-600 text-gray-200' : 'bg-gray-100 border-gray-300 text-gray-800'}`}
              />
              <button
                type="button"
                className={`px-3 py-2 rounded-xl ${darkMode ? 'bg-gray-700 hover:bg-gray-600 text-gray-200' : 'bg-gray-100 hover:bg-gray-200 text-gray-700'}`}
                onClick={() => {
                  if (!binanceAddress) return;
                  navigator.clipboard.writeText(binanceAddress).then(()=>{
                    setCopied(true);
                    setTimeout(()=>setCopied(false), 2000);
                  });
                }}
              >
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
            <p className={`text-xs mt-1.5 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Send to this address, then upload screenshot below.</p>
          </div>

          {/* Screenshot Upload */}
          <div className="mb-5">
            <label className={`block text-sm font-medium mb-1.5 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Upload Binance Transaction Screenshot
            </label>
            <div className="flex items-center gap-3">
              <label className={`inline-flex items-center gap-2 px-3 py-2 rounded-xl cursor-pointer ${darkMode ? 'bg-gray-700 hover:bg-gray-600 text-gray-200' : 'bg-gray-100 hover:bg-gray-200 text-gray-700'}`}>
                <ImageIcon className="w-5 h-5" />
                <span>Select Image</span>
                <input type="file" accept="image/*" className="hidden" onChange={(e) => {
                  const f = e.target.files?.[0] || null;
                  setFile(f);
                  setFileError(null);
                }} />
              </label>
              {file && (
                <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{file.name}</span>
              )}
            </div>
            {fileError && <div className="mt-2 text-sm text-red-500">{fileError}</div>}
          </div>

          {/* Submit Button */}
          <button
            onClick={submit}
            disabled={loading}
            className={`w-full relative overflow-hidden py-3.5 rounded-xl font-bold text-base transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center gap-2
              ${loading
                ? "bg-gray-500 cursor-not-allowed"
                : darkMode
                ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-2xl"
                : "bg-gradient-to-r from-violet-600 to-pink-600 text-white hover:shadow-2xl"
              }`}
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Adding...
              </>
            ) : (
              <>
                <Wallet className="w-5 h-5" />
                Add Balance
              </>
            )}
          </button>

          {/* Toast Messages */}
          <div className="mt-4 space-y-2">
            {success && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-700 text-white shadow-lg animate-in slide-in-from-bottom text-sm">
                <CheckCircle className="w-5 h-5" />
                <span>{success}</span>
              </div>
            )}
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-lg animate-in slide-in-from-bottom text-sm">
                <XCircle className="w-5 h-5" />
                <span>{error}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}