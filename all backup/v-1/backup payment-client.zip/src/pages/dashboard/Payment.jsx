import React, { useEffect, useMemo, useState } from "react";
import { useAuthStore } from "../../store/authStore";
import { getPayments } from "../../lib/api";
import { Filter, Search, DollarSign, Calendar, Smartphone, Hash, Sparkles } from "lucide-react";

export default function Payment() {
  const token = useAuthStore((s) => s.token);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [limit, setLimit] = useState(20);

  const [provider, setProvider] = useState("");
  const [min, setMin] = useState("");
  const [max, setMax] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const params = useMemo(() => {
    const p = { page, limit };
    if (provider) p.provider = provider;
    if (min) p.min = min;
    if (max) p.max = max;
    if (from) p.from = from;
    if (to) p.to = to;
    return p;
  }, [page, limit, provider, min, max, from, to]);

  async function load() {
    if (!token) return;
    setLoading(true);
    setError("");
    try {
      const res = await getPayments(token, params);
      setItems(res.data || []);
      setTotal(res.total || 0);
    } catch (e) {
      setError(e?.message || "Failed to load payments");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params, token]);

  const totalPages = Math.max(1, Math.ceil(total / limit));

  function resetAndSearch() {
    setPage(1);
    load();
  }

  function resetFilters() {
    setProvider(""); setMin(""); setMax(""); setFrom(""); setTo(""); setPage(1);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white p-6 relative overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10">

        {/* Header */}
        <div className="text-center mb-12 mt-10">
          <div className="inline-flex items-center justify-center w-28 h-28 rounded-full bg-gradient-to-br from-emerald-500 to-cyan-600 p-1 shadow-2xl mb-6 animate-pulse">
            <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center">
              <DollarSign className="w-16 h-16 text-cyan-400" />
            </div>
          </div>
          <h1 className="text-6xl font-black bg-gradient-to-r from-emerald-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent">
            Payment History
          </h1>
          <p className="text-cyan-300 text-xl mt-3">Your verified cosmic transactions</p>
          <div className="flex justify-center gap-3 mt-5">
            <Sparkles className="w-6 h-6 text-emerald-400 animate-twinkle" />
            <span className="text-purple-300">Total: <strong>{total}</strong> transactions</span>
            <Sparkles className="w-6 h-6 text-cyan-400 animate-twinkle" />
          </div>
        </div>

        {/* Error / Success */}
        {error && (
          <div className="mb-8 p-5 rounded-2xl bg-gradient-to-r from-rose-500/20 to-pink-500/20 border border-rose-500/50 backdrop-blur-xl text-rose-300 text-center font-medium shadow-2xl">
            {error}
          </div>
        )}

        {/* Filters Card - Glassmorphism */}
        <div className="relative overflow-hidden rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-2xl hover:shadow-cyan-500/30 transition-all duration-500 mb-10">
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-600/20 via-transparent to-emerald-600/20 opacity-70" />
          
          <div className="relative p-8">
            <div className="flex items-center gap-4 mb-8">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-500 to-emerald-500 shadow-xl">
                <Filter className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                  Advanced Filters
                </h3>
                <p className="text-cyan-300">Find exactly what you're looking for</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-5">
              <input
                placeholder="Provider (bkash, nagad...)"
                value={provider}
                onChange={(e) => setProvider(e.target.value.value)}
                className="px-6 py-4 rounded-2xl bg-white/10 border border-white/30 backdrop-blur-xl focus:border-cyan-400 focus:ring-4 focus:ring-cyan-500/30 transition-all text-white placeholder-cyan-400"
              />
              <input
                type="number"
                placeholder="Min Amount"
                value={min}
                onChange={(e) => setMin(e.target.value)}
                className="px-6 py-4 rounded-2xl bg-white/10 border border-white/30 backdrop-blur-xl focus:border-cyan-400 focus:ring-4 focus:ring-cyan-500/30 transition-all text-white placeholder-cyan-400"
              />
              <input
                type="number"
                placeholder="Max Amount"
                value={max}
                onChange={(e) => setMax(e.target.value)}
                className="px-6 py-4 rounded-2xl bg-white/10 border border-white/30 backdrop-blur-xl focus:border-cyan-400 focus:ring-4 focus:ring-cyan-500/30 transition-all text-white placeholder-cyan-400"
              />
              <input
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="px-6 py-4 rounded-2xl bg-white/10 border border-white/30 backdrop-blur-xl focus:border-cyan-400 focus:ring-4 focus:ring-cyan-500/30 transition-all text-white"
              />
              <input
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="px-6 py-4 rounded-2xl bg-white/10 border border-white/30 backdrop-blur-xl focus:border-cyan-400 focus:ring-4 focus:ring-cyan-500/30 transition-all text-white"
              />
            </div>

            <div className="flex flex-wrap gap-4 mt-8 justify-center lg:justify-start">
              <button
                onClick={resetAndSearch}
                className="px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-600 to-emerald-600 font-bold text-lg shadow-xl hover:shadow-cyan-500/50 transform hover:scale-105 transition-all duration-300 flex items-center gap-3"
              >
                <Search className="w-6 h-6" /> Apply Filters
              </button>
              <button
                onClick={resetFilters}
                className="px-8 py-4 rounded-2xl bg-white/10 border border-white/30 backdrop-blur-xl hover:bg-white/20 transition-all duration-300"
              >
                Reset All
              </button>
              <div className="flex items-center gap-3 ml-auto">
                <span className="text-cyan-300">Per page:</span>
                <select
                  value={limit}
                  onChange={(e) => { setLimit(Number(e.target.value)); setPage(1); }}
                  className="px-5 py-3 rounded-xl bg-white/10 border border-white/30 backdrop-blur-xl text-white"
                >
                  {[10, 20, 50, 100].map(n => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Transactions Table Card */}
        <div className="relative overflow-hidden rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-2xl">
          <div className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 shadow-xl">
                <DollarSign className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Verified Transactions
              </h3>
            </div>

            <div className="overflow-x-auto">
              {loading ? (
                <div className="text-center py-20">
                  <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-white/30 border-t-cyan-400"></div>
                  <p className="mt-4 text-cyan-300">Loading your payments...</p>
                </div>
              ) : items.length === 0 ? (
                <div className="text-center py-20 text-purple-300 text-xl">
                  <Sparkles className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>No payments found with current filters</p>
                </div>
              ) : (
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-white/20 text-cyan-300">
                      <th className="pb-4 px-2"><Calendar className="w-5 h-5 inline mr-2" />Date & Time</th>
                      <th className="pb-4 px-2">Provider</th>
                      <th className="pb-4 px-2"><Hash className="w-5 h-5 inline mr-2" />TRX ID</th>
                      <th className="pb-4 px-2"><Smartphone className="w-5 h-5 inline mr-2" />Device</th>
                      <th className="pb-4 px-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((it, i) => (
                      <tr key={`${it.trxID}-${i}`} className="border-b border-white/10 hover:bg-white/5 transition-all duration-300">
                        <td className="py-5 px-2 text-sm">{new Date(it.createdAt).toLocaleString()}</td>
                        <td className="py-5 px-2 font-medium text-cyan-300">{it.title || "-"}</td>
                        <td className="py-5 px-2 font-mono text-pink-300">{it.trxID || "-"}</td>
                        <td className="py-5 px-2 text-purple-300">{it.deviceName || it.deviceId || "-"}</td>
                        <td className="py-5 px-2 text-right text-2xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
                          ৳{Number(it.amount).toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            {/* Pagination */}
            <div className="flex justify-center items-center gap-6 mt-10">
              <button
                disabled={page <= 1}
                onClick={() => setPage(p => Math.max(1, p - 1))}
                className="px-6 py-3 rounded-xl bg-white/10 border border-white/30 backdrop-blur-xl hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                ← Previous
              </button>
              <span className="text-lg font-medium text-cyan-300">
                Page <strong>{page}</strong> of <strong>{totalPages}</strong>
              </span>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                className="px-6 py-3 rounded-xl bg-white/10 border border-white/30 backdrop-blur-xl hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                Next →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Blobs */}
      <div className="fixed inset-0 pointer-events-none -z-10">
        <div className="absolute top-20 left-20 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 right-10 w-80 h-80 bg-emerald-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-20 left-40 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      {/* Same animations as Profile page */}
      <style jsx>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          50% { transform: translate(50px, -50px) scale(1.1); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob { animation: blob 25s infinite; }
        .animation-delay-2000 { animation-delay: 2s; }
        .animation-delay-4000 { animation-delay: 4s; }
        .animate-twinkle { animation: twinkle 3s infinite; }
        @keyframes twinkle {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}