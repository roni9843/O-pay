import React, { useEffect, useState, useCallback } from 'react';
import { useAuthStore } from '../../store/authStore';
import api from '../../lib/api';
import { RefreshCw, Copy, Timer, Calendar, Globe, CheckCircle } from 'lucide-react';

function formatDate(d) {
  try {
    return new Date(d).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return d;
  }
}

export default function YourPlan() {
  const token = useAuthStore((s) => s.token);
  const user = useAuthStore((s) => s.user);
  const setUser = useAuthStore((s) => s.setUser);

  const [loading, setLoading] = useState(true);
  const [subs, setSubs] = useState([]);
  const [error, setError] = useState(null);
  const [countdowns, setCountdowns] = useState({});

  const fetch = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getMySubscriptions(token);
      setSubs(data || []);
    } catch (err) {
      setError(err.message || 'Failed to load subscriptions');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!token) return;
    fetch();
  }, [token]);

  // Live Countdown
  const updateCountdown = useCallback(() => {
    const newCountdowns = {};
    subs.forEach((s) => {
      const end = new Date(s.endDate);
      const now = new Date();
      const diff = end - now;
      if (diff > 0) {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        newCountdowns[s._id] = { days, hours, minutes };
      } else {
        newCountdowns[s._id] = { days: 0, hours: 0, minutes: 0 };
      }
    });
    setCountdowns(newCountdowns);
  }, [subs]);

  useEffect(() => {
    updateCountdown();
    const interval = setInterval(updateCountdown, 60000); // Update every minute
    return () => clearInterval(interval);
  }, [updateCountdown]);

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  const getPlanColor = (color) => {
    const colors = {
      green: "from-emerald-500 to-teal-600",
      blue: "from-blue-500 to-cyan-600",
      red: "from-rose-500 to-pink-600",
      purple: "from-purple-500 to-indigo-600",
    };
    return colors[color?.toLowerCase()] || "from-gray-500 to-gray-600";
  };

  if (!token) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center">
            <XCircle className="w-10 h-10 text-white" />
          </div>
          <p className="text-xl font-bold">Please login to view subscriptions</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-violet-600 to-pink-600 bg-clip-text text-transparent">
              Your Subscriptions
            </h1>
            <p className="text-gray-500 mt-1">Manage and track your active plans</p>
          </div>
          <button
            onClick={fetch}
            disabled={loading}
            className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition-all transform hover:scale-105 shadow-lg ${
              loading
                ? "bg-gray-500 cursor-not-allowed"
                : "bg-gradient-to-r from-violet-600 to-pink-600 text-white hover:shadow-xl"
            }`}
          >
            {loading ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                Loading...
              </>
            ) : (
              <>
                <RefreshCw className="w-5 h-5" />
                Reload
              </>
            )}
          </button>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="max-w-6xl mx-auto mb-6 p-4 rounded-2xl bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg flex items-center gap-3">
          <XCircle className="w-6 h-6" />
          <span className="font-medium">{error}</span>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 animate-pulse">
              <div className="h-6 bg-gray-300 rounded w-32 mb-3"></div>
              <div className="h-10 bg-gray-300 rounded w-24"></div>
            </div>
          ))}
        </div>
      )}

      {/* Subscriptions */}
      {!loading && !error && subs.length === 0 && (
        <div className="max-w-6xl mx-auto text-center py-16">
          <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-br from-gray-500 to-gray-600 flex items-center justify-center">
            <Globe className="w-12 h-12 text-white" />
          </div>
          <p className="text-xl font-semibold">No subscriptions found</p>
          <p className="text-gray-500 mt-1">Purchase a plan to get started!</p>
        </div>
      )}

      {!loading && !error && subs.length > 0 && (
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subs.map((s) => {
            const cd = countdowns[s._id] || { days: 0, hours: 0, minutes: 0 };
            const isExpiring = cd.days === 0 && cd.hours < 24;
            const planGradient = getPlanColor(s.plan?.color);

            return (
              <div
                key={s._id}
                className="relative overflow-hidden rounded-3xl shadow-2xl bg-white/10 backdrop-blur-2xl border border-white/20"
              >
                {/* Gradient Border */}
                <div
                  className={`absolute -inset-1 bg-gradient-to-r ${planGradient} blur-xl opacity-70 animate-pulse`}
                ></div>

                <div className="relative p-6">
                  {/* Plan Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-white font-bold text-sm shadow-lg bg-gradient-to-r ${planGradient}`}>
                      <CheckCircle className="w-4 h-4" />
                      {s.plan?.name || 'Plan'}
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs font-bold ${s.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                      {s.active ? 'Active' : 'Expired'}
                    </div>
                  </div>

                  {/* Price */}
                  <div className="text-right mb-5">
                    <p className="text-3xl font-bold text-white">${s.purchasePrice}</p>
                    <p className="text-sm text-gray-400">Purchased</p>
                  </div>

                  {/* Dates */}
                  <div className="grid grid-cols-2 gap-3 mb-5 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-xs text-gray-400">Start</p>
                        <p className="font-medium">{formatDate(s.startDate)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-xs text-gray-400">End</p>
                        <p className="font-medium">{formatDate(s.endDate)}</p>
                      </div>
                    </div>
                  </div>

                  {/* Countdown */}
                  <div className={`p-4 rounded-2xl mb-5 text-white shadow-lg ${isExpiring ? 'bg-gradient-to-r from-orange-500 to-red-600 animate-pulse' : 'bg-gradient-to-r from-emerald-500 to-teal-600'}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Timer className="w-5 h-5" />
                        <span className="font-semibold">Time Left</span>
                      </div>
                      {cd.days === 0 && cd.hours === 0 && cd.minutes === 0 ? (
                        <span className="text-sm">Expired</span>
                      ) : (
                        <div className="flex gap-2 text-lg font-bold">
                          <span>{cd.days}d</span>
                          <span>{cd.hours}h</span>
                          <span>{cd.minutes}m</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Domains */}
                  <div>
                    <p className="text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Domains
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {(s.domains || []).map((d, i) => (
                        <div
                          key={i}
                          className="group flex items-center gap-1 bg-white/10 backdrop-blur-xl px-3 py-1.5 rounded-full text-xs font-medium text-gray-200 border border-white/20"
                        >
                          <span>{d}</span>
                          <button
                            onClick={() => copyToClipboard(d)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}