import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Users from './pages/Users'
import UserDetail from './pages/UserDetail'
import WalletAgents from './pages/WalletAgents'
import DeviceOnline from './pages/DeviceOnline'
import Payments from './pages/Payments'
import PendingBalances from './pages/PendingBalances'
import BinanceAddress from './pages/BinanceAddress'
import Devices from './pages/Devices'
import Settings from './pages/Settings'
import OpayBusiness from './pages/OpayBusiness'
import PrivateRoute from './components/PrivateRoute'
import AdminLayout from './layouts/AdminLayout'

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route element={<PrivateRoute><AdminLayout /></PrivateRoute>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/users" element={<Users />} />
        <Route path="/users/:id" element={<UserDetail />} />
        <Route path="/wallet-agents" element={<WalletAgents />} />
        <Route path="/opay-business" element={<OpayBusiness />} />
        <Route path="/device-online" element={<DeviceOnline />} />
        <Route path="/payments" element={<Payments />} />
        <Route path="/pending-balances" element={<PendingBalances />} />
        <Route path="/binance-address" element={<BinanceAddress />} />
        <Route path="/devices" element={<Devices />} />
        <Route path="/settings" element={<Settings />} />
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}
