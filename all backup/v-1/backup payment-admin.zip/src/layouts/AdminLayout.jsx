import React from 'react'
import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import logo from '../asstes/appstore.png'
import {
  LayoutDashboard,
  Users,
  Wallet,
  Smartphone,
  CreditCard,
  Clock,
  Coins,
  Settings as SettingsIcon,
  LogOut,
  Activity,
  Briefcase,
} from 'lucide-react'

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, accent: 'from-violet-500 to-indigo-500' },
  { to: '/users', label: 'Users', icon: Users, accent: 'from-emerald-500 to-teal-500' },
  { to: '/wallet-agents', label: 'Wallet Agents', icon: Wallet, accent: 'from-pink-500 to-rose-500' },
  { to: '/opay-business', label: 'Opay Business', icon: Briefcase, accent: 'from-sky-500 to-cyan-500' },
  { to: '/device-online', label: 'Device Online', icon: Smartphone, accent: 'from-amber-500 to-orange-500' },
  { to: '/devices', label: 'Devices', icon: Smartphone, accent: 'from-fuchsia-500 to-purple-500' },
  { to: '/payments', label: 'Payments', icon: CreditCard, accent: 'from-emerald-500 to-lime-500' },
  { to: '/pending-balances', label: 'Pending Balances', icon: Clock, accent: 'from-cyan-500 to-blue-500' },
  { to: '/binance-address', label: 'Binance Address', icon: Coins, accent: 'from-yellow-400 to-orange-500' },
  { to: '/settings', label: 'Settings', icon: SettingsIcon, accent: 'from-slate-500 to-slate-400' },
]

export default function AdminLayout() {
  const navigate = useNavigate()
  const location = useLocation()
  const { user, logout } = useAuthStore()

  const activeItem = navItems.find((item) => location.pathname.startsWith(item.to))

  return (
    <div className="min-h-screen flex bg-slate-950 text-slate-100">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-72 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border-r border-slate-800/80 backdrop-blur-xl relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 opacity-40">
          <div className="absolute -left-16 top-16 h-40 w-40 rounded-full bg-violet-600/40 blur-3xl" />
          <div className="absolute -right-16 bottom-24 h-40 w-40 rounded-full bg-sky-500/30 blur-3xl" />
        </div>
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800/80 relative z-10">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-2xl flex items-center justify-center shadow-lg overflow-hidden">
              <img src={logo} alt="Oracle Admin" className="h-9 w-9 object-contain" />
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">Oracle Admin</h1>
              <p className="text-[11px] uppercase tracking-[0.18em] text-slate-400">Control Center</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-700/70 scrollbar-track-transparent relative z-10">
          {navItems.map((item) => {
            const Icon = item.icon
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all duration-200 border border-transparent ${
                    isActive
                      ? `bg-gradient-to-r ${item.accent} text-white shadow-lg border-violet-400/60`
                      : 'text-slate-300/90 hover:text-white hover:bg-slate-800/70 hover:border-slate-700/80'
                  }`
                }
              >
                <div
                  className={`flex h-7 w-7 items-center justify-center rounded-xl bg-slate-900/70 border border-slate-700/70 group-hover:border-violet-400/60 transition-colors ${
                    'shadow-[0_0_0_1px_rgba(148,163,184,0.2)]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1 flex items-center justify-between min-w-0">
                  <span className="font-medium truncate">{item.label}</span>
                  <Activity className="hidden md:block w-3 h-3 text-slate-500 group-hover:text-emerald-400" />
                </div>
              </NavLink>
            )
          })}
        </nav>

        <div className="px-4 py-4 border-t border-slate-800/80 relative z-10 bg-slate-950/60">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-xs text-slate-400">Logged in as</p>
              <p className="text-sm font-medium truncate max-w-[11rem]">
                {user?.name || user?.email || 'Admin'}
              </p>
            </div>
            <button
              onClick={() => {
                logout()
                navigate('/login')
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-100 hover:bg-rose-600/90 hover:text-white transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              Logout
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-20 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl">
          <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-sm font-semibold text-white shadow-lg">
                {activeItem?.label?.[0] || 'A'}
              </div>
              <div className="min-w-0">
                <h2 className="text-sm font-semibold leading-tight truncate">
                  {activeItem?.label || 'Admin Dashboard'}
                </h2>
                <p className="text-[11px] text-slate-400 truncate">
                  Oracle admin panel · manage users, agents, devices & payments
                </p>
              </div>
            </div>

            <div className="hidden sm:flex items-center gap-3 text-xs text-slate-300">
              <div className="flex flex-col items-end">
                <span className="font-medium truncate max-w-[10rem]">
                  {user?.name || user?.email || 'Administrator'}
                </span>
                <span className="text-[11px] text-slate-400">Super Admin</span>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 bg-slate-950 overflow-x-hidden">
          <div className="mx-auto max-w-6xl px-4 py-5">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}
