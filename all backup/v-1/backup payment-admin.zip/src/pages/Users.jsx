import React, { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { listUsers, createUser } from '../lib/api'
import { Link } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import { Users as UsersIcon, UserPlus, Loader2, X, Search } from 'lucide-react'

export default function Users() {
  const token = useAuthStore(s => s.token)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [items, setItems] = useState([])
  const [query, setQuery] = useState('')
  const [creating, setCreating] = useState(false)
  const [createError, setCreateError] = useState('')
  const [createLoading, setCreateLoading] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'user' })

  useEffect(() => {
    let ignore = false
    async function load() {
      if (!token) return
      setLoading(true)
      setError('')
      try {
        const res = await listUsers(token, { page: 1, limit: 20 })
        if (!ignore) setItems(res.data || [])
      } catch (e) {
        if (!ignore) setError(e.message || 'Failed to load users')
      } finally {
        if (!ignore) setLoading(false)
      }
    }
    load()
    return () => { ignore = true }
  }, [token])

  async function handleCreate(e) {
    e.preventDefault()
    if (!token) return
    setCreateError('')
    if (!form.name || !form.email || !form.password) {
      setCreateError('Name, email and password are required')
      return
    }
    try {
      setCreateLoading(true)
      await createUser(token, {
        name: form.name,
        email: form.email,
        password: form.password,
        role: form.role,
      })
      setForm({ name: '', email: '', password: '', role: 'user' })
      setCreating(false)

      // reload
      const res = await listUsers(token, { page: 1, limit: 20 })
      setItems(res.data || [])
    } catch (err) {
      setCreateError(err.message || 'Failed to create user')
    } finally {
      setCreateLoading(false)
    }
  }

  const filtered = items.filter(u => {
    if (!query.trim()) return true
    const q = query.toLowerCase()
    return (
      (u.name?.toLowerCase().includes(q)) ||
      (u.email?.toLowerCase().includes(q)) ||
      (u.role?.toLowerCase().includes(q))
    )
  })

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-indigo-950 via-purple-950 to-fuchsia-950 pb-12">
      {/* Animated background orbs */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-40 h-96 w-96 animate-pulse-slow rounded-full bg-gradient-radial from-violet-600/25 to-transparent blur-3xl" />
        <div className="absolute top-20 right-10 h-80 w-80 animate-pulse-slow-delay rounded-full bg-gradient-radial from-cyan-500/20 to-transparent blur-3xl" />
        <div className="absolute -bottom-40 left-20 h-96 w-96 animate-pulse-slow-2 rounded-full bg-gradient-radial from-pink-500/15 to-transparent blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 pt-8 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
        >
          <div className="flex flex-col gap-2">
            <h2 className="inline-flex items-center gap-3 text-3xl font-bold tracking-tight">
              <motion.span
                animate={{ scale: [1, 1.15, 1] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 to-fuchsia-700 text-white shadow-lg"
              >
                <UsersIcon className="w-5 h-5" />
              </motion.span>
              <span className="bg-gradient-to-r from-violet-300 via-fuchsia-300 to-cyan-200 bg-clip-text text-transparent">
                Users Galaxy
              </span>
            </h2>
            <p className="text-slate-300/80">Manage platform members, roles & wallet access</p>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search users..."
                className="pl-10 pr-4 py-2 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/50 w-64"
              />
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => { setCreating(true); setCreateError('') }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-900 font-semibold shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 transition-all"
            >
              <UserPlus className="w-4 h-4" />
              Add User
            </motion.button>
          </div>
        </motion.div>

        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="rounded-2xl bg-red-950/40 border border-red-400/30 backdrop-blur-xl p-4 text-red-200"
          >
            {error}
          </motion.div>
        )}

        {/* Create User Modal */}
        <AnimatePresence>
          {creating && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
            >
              <motion.div
                initial={{ scale: 0.9, y: 20, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.9, y: 20, opacity: 0 }}
                className="relative w-full max-w-lg rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-violet-600/10 to-cyan-600/10 pointer-events-none" />

                <div className="relative p-6 space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-semibold text-white">Create New Orbit User</h3>
                    <button
                      onClick={() => setCreating(false)}
                      className="text-slate-300 hover:text-white"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>

                  <form onSubmit={handleCreate} className="space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm text-slate-300 mb-1.5">Name</label>
                        <input
                          type="text"
                          value={form.name}
                          onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                          className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-slate-400 focus:outline-none focus:border-violet-400/50 backdrop-blur-sm"
                          placeholder="Enter full name"
                        />
                      </div>
                      <div>
                        <label className="block text-sm text-slate-300 mb-1.5">Email</label>
                        <input
                          type="email"
                          value={form.email}
                          onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                          className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-slate-400 focus:outline-none focus:border-violet-400/50 backdrop-blur-sm"
                          placeholder="user@domain.com"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm text-slate-300 mb-1.5">Password</label>
                        <input
                          type="password"
                          value={form.password}
                          onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                          className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-slate-400 focus:outline-none focus:border-violet-400/50 backdrop-blur-sm"
                          placeholder="••••••••"
                        />
                      </div>
                      <div>
                        <label className="block text-sm text-slate-300 mb-1.5">Role</label>
                        <select
                          value={form.role}
                          onChange={e => setForm(f => ({ ...f, role: e.target.value }))}
                          className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white focus:outline-none focus:border-violet-400/50 backdrop-blur-sm appearance-none"
                        >
                          <option value="user">Normal User</option>
                          <option value="wallet_agent">Wallet Agent</option>
                          {/* যদি admin role থাকে তাহলে যোগ করতে পারো */}
                        </select>
                      </div>
                    </div>

                    {createError && (
                      <div className="text-red-400 text-sm">{createError}</div>
                    )}

                    <div className="flex justify-end gap-3 pt-3">
                      <button
                        type="button"
                        onClick={() => setCreating(false)}
                        className="px-6 py-2.5 rounded-2xl border border-white/20 text-slate-300 hover:bg-white/10 transition"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={createLoading}
                        className="inline-flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-medium shadow-lg disabled:opacity-50"
                      >
                        {createLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                        {createLoading ? 'Creating...' : 'Create User'}
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Users Table - Glassmorphic */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl overflow-hidden"
        >
          <div className="px-6 py-4 border-b border-white/10">
            <h3 className="text-lg font-semibold text-white">All Platform Users</h3>
            <p className="text-sm text-slate-400 mt-1">
              Total: {items.length} • Showing: {filtered.length}
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/10 text-xs uppercase tracking-wider text-slate-400">
                  <th className="px-6 py-4 text-left">Name</th>
                  <th className="px-6 py-4 text-left">Email</th>
                  <th className="px-6 py-4 text-left">Role</th>
                  <th className="px-6 py-4 text-left">Balance</th>
                  <th className="px-6 py-4 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-slate-400">
                      <div className="inline-flex items-center gap-3">
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Loading users...
                      </div>
                    </td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-16 text-center text-slate-500">
                      No users found matching your search
                    </td>
                  </tr>
                ) : (
                  filtered.map((u, idx) => (
                    <motion.tr
                      key={u._id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="border-b border-white/5 hover:bg-white/5 transition-colors group"
                    >
                      <td className="px-6 py-4 font-medium text-white">{u.name || '—'}</td>
                      <td className="px-6 py-4 text-slate-300">{u.email}</td>
                      <td className="px-6 py-4">
                        <span
                          className={`inline-flex px-3 py-1 rounded-full text-xs font-medium border
                            ${u.role === 'admin' ? 'bg-rose-950/40 border-rose-500/30 text-rose-300'
                              : u.role === 'wallet_agent' ? 'bg-amber-950/40 border-amber-500/30 text-amber-300'
                              : 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'}`}
                        >
                          {u.role || 'user'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-emerald-400 font-medium">
                        {typeof u.balance === 'number' ? `৳${u.balance.toFixed(2)}` : '—'}
                      </td>
                      <td className="px-6 py-4">
                        <Link
                          to={`/users/${u._id}`}
                          className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-violet-600/80 hover:bg-violet-500 text-white text-xs font-medium transition"
                        >
                          View / Edit →
                        </Link>
                      </td>
                    </motion.tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  )
}