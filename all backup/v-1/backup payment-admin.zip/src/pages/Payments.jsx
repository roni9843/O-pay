import React, { useEffect, useState } from 'react'
import { useAuthStore } from '../store/authStore'
import { uploadPaymentPageImage, getWalletAgentTemplates, saveWalletAgentTemplate } from '../lib/api'

export default function Payments() {
  const token = useAuthStore((s) => s.token)
  const [templates, setTemplates] = useState([])
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [form, setForm] = useState({
    provider: 'bkash',
    gateway: 'personal',
    methodName: '',
    note: '',
    importantNote: '',
    detailsText: '',
    image: '',
    color: '#000000',
    bgColor: '#ffffff',
    buttonText: '',
    buttonTextColor: '#ffffff',
    buttonTextBgColor: '#4f46e5',
  })

  useEffect(() => {
    if (!token) return
    setLoading(true)
    getWalletAgentTemplates(token)
      .then((res) => {
        const data = Array.isArray(res?.data) ? res.data : []
        setTemplates(data)
      })
      .catch(() => setError('Failed to load templates'))
      .finally(() => setLoading(false))
  }, [token])

  const resetForm = () => {
    setForm({
      provider: 'bkash',
      gateway: 'personal',
      methodName: '',
      note: '',
      importantNote: '',
      detailsText: '',
      image: '',
      color: '#000000',
      bgColor: '#ffffff',
      buttonText: '',
      buttonTextColor: '#ffffff',
      buttonTextBgColor: '#4f46e5',
    })
  }

  const handleSelectExisting = (provider, gateway) => {
    const tpl = templates.find((t) => t.provider === provider && t.gateway === gateway)
    if (!tpl) {
      setForm((prev) => ({ ...prev, provider, gateway, methodName: '', note: '', importantNote: '', detailsText: '', image: '' }))
      return
    }
    setForm({
      provider: tpl.provider,
      gateway: tpl.gateway,
      methodName: tpl.methodName || '',
      note: tpl.note || '',
      importantNote: tpl.importantNote || '',
      detailsText: Array.isArray(tpl.details) ? tpl.details.join('\n') : '',
      image: tpl.image || '',
      color: tpl.color || '#000000',
      bgColor: tpl.bgColor || '#ffffff',
      buttonText: tpl.buttonText || '',
      buttonTextColor: tpl.buttonTextColor || '#ffffff',
      buttonTextBgColor: tpl.buttonTextBgColor || '#4f46e5',
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.provider || !form.gateway || !form.methodName) return
    setSaving(true)
    setError('')
    setSuccess('')
    try {
      const details = form.detailsText
        ? form.detailsText
            .split('\n')
            .map((d) => d.trim())
            .filter(Boolean)
        : []
      const res = await saveWalletAgentTemplate(token, {
        provider: form.provider,
        gateway: form.gateway,
        methodName: form.methodName,
        note: form.note,
        importantNote: form.importantNote,
        details,
        image: form.image,
        color: form.color,
        bgColor: form.bgColor,
        buttonText: form.buttonText,
        buttonTextColor: form.buttonTextColor,
        buttonTextBgColor: form.buttonTextBgColor,
      })
      const updated = templates.filter((t) => !(t.provider === res.data.provider && t.gateway === res.data.gateway))
      setTemplates([...updated, res.data])
      setSuccess('Template saved for wallet agents')
    } catch (err) {
      setError(err?.data?.message || err.message || 'Failed to save template')
    } finally {
      setSaving(false)
    }
  }

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file || !token) return
    try {
      const res = await uploadPaymentPageImage(token, file)
      if (res?.url) {
        setForm((prev) => ({ ...prev, image: res.url }))
      }
    } catch (err) {
      setError(err.message || 'Image upload failed')
    }
  }

  const matrix = [
    { provider: 'bkash', label: 'bKash' },
    { provider: 'nagad', label: 'Nagad' },
    { provider: 'rocket', label: 'Rocket' },
    { provider: 'upay', label: 'Upay' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Wallet Agent Global Payment Templates</h2>
        <p className="text-sm text-gray-500">
          Admin এখান থেকে bkash / nagad / rocket / upay এর personal & agent  payment page template সেট করবে। সব wallet agent এই template অনুযায়ী পেমেন্ট পেজ পাবে।
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-5 space-y-4">
          <h3 className="text-lg font-semibold mb-2">১. Template Overview</h3>
          {loading ? (
            <p className="text-sm text-gray-500">লোড হচ্ছে...</p>
          ) : (
            <div className="space-y-3 text-sm">
              {matrix.map((row) => (
                <div key={row.provider} className="border rounded-md p-3 bg-gray-50 dark:bg-gray-800">
                  <div className="font-semibold mb-2">{row.label}</div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {['personal', 'merchant'].map((gw) => {
                      const tpl = templates.find((t) => t.provider === row.provider && t.gateway === gw)
                      return (
                        <button
                          key={gw}
                          type="button"
                          onClick={() => handleSelectExisting(row.provider, gw)}
                          className={`border rounded px-2 py-1 text-left hover:bg-indigo-50 dark:hover:bg-indigo-900 ${
                            tpl ? 'border-green-500 text-green-700' : 'border-gray-300 text-gray-600'
                          }`}
                        >
                          <div className="font-semibold">{gw === 'merchant' ? 'Agent' : 'Personal'}</div>
                          <div className="text-[11px] truncate">
                            {tpl ? tpl.methodName || 'Configured' : 'Not configured'}
                          </div>
                        </button>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-5 space-y-4">
          <h3 className="text-lg font-semibold mb-2">২. Template কনফিগার / আপডেট</h3>
          <p className="text-xs text-gray-500 mb-2">
            এখানে সেট করা template সব wallet agent এর জন্য প্রযোজ্য হবে, আলাদা করে কারও জন্য পেজ বানাতে হবে না।
          </p>

          <form onSubmit={handleSubmit} className="space-y-3 text-sm">
            {error && <p className="text-xs text-red-600">{error}</p>}
            {success && <p className="text-xs text-green-600">{success}</p>}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Provider</label>
                <select
                  value={form.provider}
                  onChange={(e) => setForm((p) => ({ ...p, provider: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                >
                  <option value="bkash">bKash</option>
                  <option value="nagad">Nagad</option>
                  <option value="rocket">Rocket</option>
                  <option value="upay">Upay</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Gateway</label>
                <select
                  value={form.gateway}
                  onChange={(e) => setForm((p) => ({ ...p, gateway: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                >
                  <option value="personal">Personal</option>
                  <option value="merchant">Agent</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Method Name *</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                value={form.methodName}
                onChange={(e) => setForm((p) => ({ ...p, methodName: e.target.value }))}
                placeholder="যেমন: bKash Personal / bKash Agent"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">নোট (optional)</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                value={form.note}
                onChange={(e) => setForm((p) => ({ ...p, note: e.target.value }))}
                placeholder="যেমন: শুধুমাত্র personal number"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">গুরুত্বপূর্ণ নোট</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                value={form.importantNote}
                onChange={(e) => setForm((p) => ({ ...p, importantNote: e.target.value }))}
                placeholder="যেমন: ৫ মিনিটের ভিতরে পেমেন্ট করুন"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">ডিটেইলস (প্রতি লাইনে একটি করে instruction)</label>
              <textarea
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-xs"
                value={form.detailsText}
                onChange={(e) => setForm((p) => ({ ...p, detailsText: e.target.value }))}
                placeholder={"১. Send money অপশন সিলেক্ট করুন\n২. নিচের নম্বরে টাকা পাঠান"}
              />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Text Color</label>
                <input
                  type="color"
                  className="w-full h-8 rounded-md border-gray-300"
                  value={form.color}
                  onChange={(e) => setForm((p) => ({ ...p, color: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Background</label>
                <input
                  type="color"
                  className="w-full h-8 rounded-md border-gray-300"
                  value={form.bgColor}
                  onChange={(e) => setForm((p) => ({ ...p, bgColor: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Button BG</label>
                <input
                  type="color"
                  className="w-full h-8 rounded-md border-gray-300"
                  value={form.buttonTextBgColor}
                  onChange={(e) => setForm((p) => ({ ...p, buttonTextBgColor: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Button Text</label>
                <input
                  type="color"
                  className="w-full h-8 rounded-md border-gray-300"
                  value={form.buttonTextColor}
                  onChange={(e) => setForm((p) => ({ ...p, buttonTextColor: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Button Text</label>
              <input
                type="text"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                value={form.buttonText}
                onChange={(e) => setForm((p) => ({ ...p, buttonText: e.target.value }))}
                placeholder="যেমন: এখনই পেমেন্ট করুন"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">ইমেজ (ঐচ্ছিক)</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="mt-1 block w-full text-xs text-gray-500 file:mr-4 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700"
              />
              {form.image && (
                <div className="mt-2 flex items-center gap-2">
                  <img
                    src={form.image}
                    alt="Preview"
                    className="h-10 w-auto rounded border border-gray-300 bg-gray-50 object-contain"
                  />
                  <button
                    type="button"
                    onClick={() => setForm((p) => ({ ...p, image: '' }))}
                    className="text-xs text-red-600 hover:underline"
                  >
                    মুছুন
                  </button>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={resetForm}
                className="px-3 py-1.5 rounded-md border border-gray-300 text-xs text-gray-700 hover:bg-gray-50"
              >
                রিসেট
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-4 py-1.5 rounded-md bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 disabled:opacity-60"
              >
                {saving ? 'সেভ হচ্ছে...' : 'টেমপ্লেট সেভ করুন'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
