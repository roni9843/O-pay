import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuthStore } from '../store/authStore'
import { getStats, listDevicesOnlineStatus, listPayments } from '../lib/api'
import {
  Users,
  MonitorSmartphone,
  CheckCircle2,
  Clock,
  Wallet,
  ArrowUpRight,
} from 'lucide-react'

export default function Dashboard() {
  const token = useAuthStore((s) => s.token)
  const [stats, setStats] = React.useState(null)
  const [deviceStatus, setDeviceStatus] = React.useState({ online: 0, total: 0 })
  const [recentPayments, setRecentPayments] = React.useState([])
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState('')

  React.useEffect(() => {
    if (!token) return
    let cancelled = false

    async function load() {
      setLoading(true)
      setError('')
      try {
        const [statsRes, devicesRes, paymentsRes] = await Promise.all([
          getStats(token),
          listDevicesOnlineStatus(token),
          listPayments(token, { page: 1, limit: 8 }), // একটু বেশি দেখানো যাক
        ])

        if (cancelled) return

        setStats(statsRes?.data || null)
        const devs = devicesRes?.data || []
        const online = devs.filter((d) => d.online).length
        setDeviceStatus({ online, total: devs.length })
        setRecentPayments(paymentsRes?.data || [])
      } catch (err) {
        if (!cancelled) setError(err.message || 'Failed to load dashboard data')
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    load()
    return () => { cancelled = true }
  }, [token])

  const totalVolume = React.useMemo(
    () => recentPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0),
    [recentPayments]
  )

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-indigo-950 via-purple-950 to-fuchsia-950 pb-20 rounded-3xl">
      {/* Animated background glows */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-40 h-96 w-96 animate-pulse-slow rounded-full bg-gradient-radial from-violet-600/30 to-transparent blur-3xl" />
        <div className="absolute -top-20 right-0 h-80 w-80 animate-pulse-slow-delay rounded-full bg-gradient-radial from-cyan-500/25 to-transparent blur-3xl" />
        <div className="absolute bottom-0 -right-20 h-[500px] w-[500px] animate-pulse-slow-2 rounded-full bg-gradient-radial from-emerald-500/20 to-transparent blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl space-y-8 px-4 pt-8 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="flex flex-col gap-2"
        >
          <h2 className="inline-flex items-center gap-3 text-3xl font-bold tracking-tight">
            <motion.span
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 text-white text-sm font-bold shadow-lg"
            >
              ●
            </motion.span>
            <span className="bg-gradient-to-r from-violet-300 via-fuchsia-300 to-cyan-300 bg-clip-text text-transparent">
              Cosmic Dashboard
            </span>
          </h2>
          <p className="text-base text-slate-300/80">
            Real-time colorful overview of your platform's pulse ✨
          </p>
        </motion.div>

        {error && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="rounded-2xl border border-red-400/30 bg-red-950/40 backdrop-blur-xl px-5 py-4 text-red-200 shadow-xl"
          >
            ⚠️ {error}
          </motion.div>
        )}

        {/* Summary Cards - Glassmorphic + hover glow */}
        <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          <AnimatedSummaryCard
            title="Total Users"
            value={stats?.usersCount ?? '--'}
            icon={Users}
            color="from-emerald-400 via-teal-500 to-cyan-500"
            delay={0.1}
          />
          <AnimatedSummaryCard
            title="Devices Registered"
            value={stats?.devicesCount ?? '--'}
            icon={MonitorSmartphone}
            color="from-blue-400 via-indigo-500 to-violet-600"
            delay={0.2}
          />
          <AnimatedSummaryCard
            title="Verified Payments"
            value={stats?.verifiedPayments ?? '--'}
            icon={CheckCircle2}
            color="from-violet-500 via-fuchsia-600 to-pink-500"
            delay={0.3}
          />
          <AnimatedSummaryCard
            title="Pending Top-ups"
            value={stats?.pendingTopUps ?? '--'}
            icon={Clock}
            color="from-amber-400 via-orange-500 to-rose-500"
            delay={0.4}
          />
        </div>

        {/* Middle section */}
        <div className="grid gap-6 grid-cols-1 lg:grid-cols-3">
          {/* Device Status - Animated progress */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.7 }}
            className="group relative rounded-3xl border border-white/10 bg-white/5 backdrop-blur-2xl p-6 shadow-2xl transition-all hover:border-white/20 hover:shadow-[0_0_30px_rgba(16,185,129,0.3)]"
          >
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-emerald-600/10 to-cyan-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />

            <div className="relative z-10">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-white">Device Pulse</h3>
                  <p className="text-xs text-slate-400">Live online activity</p>
                </div>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                >
                  <MonitorSmartphone className="h-6 w-6 text-emerald-400" />
                </motion.div>
              </div>

              <div className="mb-4 flex items-baseline gap-3">
                <motion.span
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-5xl font-extrabold text-emerald-400 drop-shadow-lg"
                >
                  {deviceStatus.online}
                </motion.span>
                <span className="text-xl text-slate-300">/ {deviceStatus.total}</span>
              </div>

              <div className="relative h-4 w-full overflow-hidden rounded-full bg-slate-900/60 backdrop-blur-sm">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{
                    width: deviceStatus.total > 0
                      ? `${(deviceStatus.online / deviceStatus.total) * 100}%`
                      : '0%'
                  }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-emerald-400 to-cyan-400 shadow-[0_0_15px_rgba(52,211,153,0.7)]"
                />
              </div>

              <div className="mt-5 grid grid-cols-2 gap-4">
                <div className="rounded-2xl bg-emerald-950/40 backdrop-blur-sm border border-emerald-500/30 p-4 text-center">
                  <div className="text-xs text-emerald-300">Online</div>
                  <div className="text-2xl font-bold text-emerald-400">{deviceStatus.online}</div>
                </div>
                <div className="rounded-2xl bg-slate-900/40 backdrop-blur-sm border border-slate-600/50 p-4 text-center">
                  <div className="text-xs text-slate-400">Offline</div>
                  <div className="text-2xl font-bold text-slate-300">
                    {Math.max(0, deviceStatus.total - deviceStatus.online)}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Recent Payments Table - Glass + hover rows */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6, duration: 0.7 }}
            className="group relative col-span-1 lg:col-span-2 rounded-3xl border border-white/10 bg-white/5 backdrop-blur-2xl p-6 shadow-2xl transition-all hover:border-white/20 hover:shadow-[0_0_40px_rgba(168,85,247,0.3)]"
          >
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-violet-600/10 to-fuchsia-600/5 opacity-0 group-hover:opacity-100 transition-opacity" />

            <div className="relative z-10 mb-5 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-white">Recent Cosmic Transactions</h3>
                <p className="text-xs text-slate-400">Latest verified payments flowing in</p>
              </div>
              <div className="flex items-center gap-2 rounded-full bg-emerald-950/50 px-4 py-2 text-sm backdrop-blur-sm border border-emerald-500/30">
                <Wallet className="h-4 w-4 text-emerald-400" />
                <span className="font-medium text-emerald-300">৳{totalVolume.toFixed(2)}</span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm text-slate-200">
                <thead>
                  <tr className="border-b border-white/10 text-xs uppercase tracking-wider text-slate-400">
                    <th className="py-4 pr-4 text-left">Trx ID</th>
                    <th className="py-4 px-3 text-left">Provider</th>
                    <th className="py-4 px-3 text-left">User</th>
                    <th className="py-4 px-3 text-left">Device</th>
                    <th className="py-4 px-3 text-right">Amount</th>
                    <th className="py-4 pl-3 text-right">Time</th>
                  </tr>
                </thead>
                <tbody>
                  <AnimatePresence>
                    {loading ? (
                      // Skeleton rows
                      Array.from({ length: 5 }).map((_, i) => (
                        <tr key={`skeleton-${i}`}>
                          <td colSpan={6} className="py-5">
                            <div className="h-5 w-full animate-pulse rounded bg-slate-700/50" />
                          </td>
                        </tr>
                      ))
                    ) : recentPayments.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-500">
                          No transactions orbiting yet... 🌌
                        </td>
                      </tr>
                    ) : (
                      recentPayments.map((p, index) => (
                        <motion.tr
                          key={p._id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.7 + index * 0.1 }}
                          className="group/row border-b border-white/5 hover:bg-white/5 transition-colors"
                        >
                          <td className="py-4 pr-4 font-mono text-violet-300">{p.trxID || '—'}</td>
                          <td className="py-4 px-3">
                            <span className="inline-flex rounded-full bg-violet-950/60 px-3 py-1 text-xs font-medium text-violet-300 backdrop-blur-sm border border-violet-500/30">
                              {p.title || 'Unknown'}
                            </span>
                          </td>
                          <td className="py-4 px-3">
                            {p.owner ? (
                              <div className="space-y-1">
                                <div className="font-medium text-white truncate max-w-[140px]">
                                  {p.owner.name || 'Ghost User'}
                                </div>
                                <div className="text-xs text-slate-400 truncate max-w-[160px]">
                                  {p.owner.email}
                                </div>
                              </div>
                            ) : '—'}
                          </td>
                          <td className="py-4 px-3">
                            {p.deviceResolved ? (
                              <div className="space-y-1">
                                <div className="font-medium text-cyan-300 truncate max-w-[140px]">
                                  {p.deviceResolved.deviceUserName || p.deviceResolved.deviceName || 'Phantom'}
                                </div>
                                <div className="text-xs text-slate-500 truncate max-w-[160px]">
                                  {p.deviceResolved.deviceName}
                                </div>
                              </div>
                            ) : '—'}
                          </td>
                          <td className="py-4 px-3 text-right font-bold text-emerald-400">
                            ৳{Number(p.amount || 0).toFixed(2)}
                          </td>
                          <td className="py-4 pl-3 text-right text-xs text-slate-400">
                            {p.createdAt ? new Date(p.createdAt).toLocaleString() : '—'}
                          </td>
                        </motion.tr>
                      ))
                    )}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>

        {loading && !error && (
          <motion.div
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="flex items-center justify-center gap-3 text-violet-300"
          >
            <ArrowUpRight className="h-5 w-5 animate-bounce" />
            <span>Fetching cosmic data...</span>
          </motion.div>
        )}
      </div>
    </div>
  )
}

function AnimatedSummaryCard({ title, value, icon: Icon, color, delay }) {
  const isNumber = typeof value === 'number'

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.7, type: "spring", stiffness: 120 }}
      whileHover={{ scale: 1.04, transition: { duration: 0.3 } }}
      className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 backdrop-blur-2xl p-6 shadow-xl hover:shadow-2xl hover:border-white/30 transition-all"
    >
      {/* Gradient overlay on hover */}
      <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-0 group-hover:opacity-20 transition-opacity duration-500`} />

      <div className="relative z-10 flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-300/90">{title}</p>
          <motion.p
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: delay + 0.3, duration: 0.6 }}
            className="mt-3 text-4xl font-extrabold tracking-tight text-white drop-shadow-lg"
          >
            {isNumber ? value.toLocaleString() : value}
          </motion.p>
        </div>

        <motion.div
          whileHover={{ rotate: 360, scale: 1.15 }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/10 to-transparent blur-xl opacity-70 group-hover:opacity-100 transition" />
          <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-slate-900/80 to-black/60 backdrop-blur-md border border-white/10 shadow-lg">
            <Icon className="h-7 w-7 text-white" />
          </div>
        </motion.div>
      </div>
    </motion.div>
  )
}