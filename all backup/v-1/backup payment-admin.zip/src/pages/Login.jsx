import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { login, me } from '../lib/api'
import { useAuthStore } from '../store/authStore'
import logo from '../asstes/appstore.png'

export default function Login() {
  const navigate = useNavigate()
  const { setToken, setUser } = useAuthStore()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function onSubmit(e) {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const res = await login({ email, password })
      setToken(res.token)
      const profile = await me(res.token)
      setUser(profile.user)
      navigate('/dashboard', { replace: true })
    } catch (err) {
      setError(err.message || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-4">
      <div className="relative w-full max-w-md">
        {/* Glow circles */}
        <div className="pointer-events-none absolute -top-10 -left-10 h-32 w-32 rounded-full bg-white/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-10 -right-10 h-32 w-32 rounded-full bg-emerald-400/30 blur-3xl" />

        <form
          onSubmit={onSubmit}
          className="relative z-10 w-full rounded-3xl bg-white/10 dark:bg-gray-900/90 border border-white/20 shadow-2xl backdrop-blur-xl px-6 py-7 sm:px-8 sm:py-8 space-y-5 text-white"
        >
          <div className="flex flex-col items-center gap-2 mb-2">
            <div className="h-12 w-12 rounded-2xl flex items-center justify-center shadow-lg overflow-hidden">
              <img src={logo} alt="Oracle Admin" className="h-10 w-10 object-contain" />
            </div>
            <div className="text-xs uppercase tracking-[0.2em] text-white/70">Admin Panel</div>
            <h1 className="text-2xl font-semibold tracking-tight">Secure Login</h1>
            <p className="text-xs text-white/70 text-center max-w-xs">
              Sign in to manage users, payments and devices in your Oracle admin dashboard.
            </p>
          </div>

          {error && (
            <div className="p-2.5 rounded-2xl bg-red-500/10 border border-red-400/60 text-red-100 text-xs">
              {error}
            </div>
          )}

          <div className="space-y-3">
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-white/80">Email</label>
              <input
                className="w-full px-3.5 py-2.5 rounded-2xl bg-white/10 border border-white/20 text-sm placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-emerald-400/80 focus:border-transparent transition-all"
                placeholder="admin@example.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-white/80">Password</label>
              <input
                className="w-full px-3.5 py-2.5 rounded-2xl bg-white/10 border border-white/20 text-sm placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-emerald-400/80 focus:border-transparent transition-all"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
            </div>
          </div>

          <button
            disabled={loading}
            className="mt-2 w-full px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-400 via-teal-400 to-sky-400 text-sm font-semibold text-gray-900 shadow-lg shadow-emerald-500/30 hover:brightness-105 disabled:opacity-70 disabled:cursor-not-allowed transition-all"
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>

          <p className="text-[11px] text-center text-white/60 pt-1">
            For authorized administrators only. All activities are monitored.
          </p>
        </form>
      </div>
    </div>
  )
}
