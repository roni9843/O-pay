import React, { useEffect, useState } from 'react'
import { listDevices, deleteDevice } from '../lib/api'
import { useAuthStore } from '../store/authStore'

export default function Devices(){
  const token = useAuthStore(s=>s.token)
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [actionError, setActionError] = useState('')
  const [deletingId, setDeletingId] = useState('')

  useEffect(() => {
    let ignore = false
    async function load(){
      if (!token) return
      setLoading(true); setError('')
      try {
        const res = await listDevices(token, { page: 1, limit: 50 })
        if (!ignore) setItems(res.data || [])
      } catch (e) {
        if (!ignore) setError(e.message || 'Failed to load devices')
      } finally {
        if (!ignore) setLoading(false)
      }
    }
    load()
    return () => { ignore = true }
  }, [token])

  async function handleDelete(id){
    if (!token) return
    setActionError('')
    const ok = window.confirm('Are you sure you want to delete this device and all related data?')
    if (!ok) return
    try {
      setDeletingId(id)
      await deleteDevice(token, id)
      setItems(list => list.filter(d => d._id !== id))
    } catch (err) {
      setActionError(err.message || 'Failed to delete device')
    } finally {
      setDeletingId('')
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Devices</h2>
        <p className="text-sm text-gray-500">Manage registered devices. Deleting a device also removes its linked payment accounts and messages.</p>
      </div>

      {error && <div className="p-3 rounded bg-red-100 text-red-700 text-sm">{error}</div>}
      {actionError && <div className="p-3 rounded bg-red-100 text-red-700 text-sm">{actionError}</div>}

      <div className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden">
        <div className="px-5 py-3 border-b dark:border-gray-800">
          <h3 className="text-lg font-medium">All Devices</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b dark:border-gray-800">
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3">Device Name</th>
                <th className="px-4 py-3">Device Code</th>
                <th className="px-4 py-3">Username</th>
                <th className="px-4 py-3">Verified Payments</th>
                <th className="px-4 py-3">Amount</th>
                <th className="px-4 py-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td className="px-4 py-3" colSpan={7}>Loading...</td></tr>
              ) : items.length === 0 ? (
                <tr><td className="px-4 py-3" colSpan={7}>No devices found</td></tr>
              ) : (
                items.map(d => (
                  <tr key={d._id} className="border-b dark:border-gray-800">
                    <td className="px-4 py-3">{d.owner ? `${d.owner.name} (${d.owner.email})` : '-'}</td>
                    <td className="px-4 py-3">{d.deviceName || '-'}</td>
                    <td className="px-4 py-3">{d.deviceCode || '-'}</td>
                    <td className="px-4 py-3">{d.deviceUserName || '-'}</td>
                    <td className="px-4 py-3">{d.verifiedPayments ?? 0}</td>
                    <td className="px-4 py-3">{d.verifiedAmount ?? 0}</td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => handleDelete(d._id)}
                        disabled={!!deletingId}
                        className="text-xs px-2 py-1 rounded bg-red-600 text-white disabled:opacity-50"
                      >
                        {deletingId === d._id ? 'Deleting...' : 'Delete'}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
