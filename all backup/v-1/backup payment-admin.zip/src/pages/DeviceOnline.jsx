import React, { useEffect, useState } from 'react'
import { listDevicesOnlineStatus } from '../lib/api'
import { useAuthStore } from '../store/authStore'

export default function DeviceOnline() {
  const token = useAuthStore(s => s.token)
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    let ignore = false
    async function load() {
      if (!token) return
      setLoading(true)
      setError('')
      try {
        const res = await listDevicesOnlineStatus(token)
        if (!ignore) setItems(res.data || [])
      } catch (e) {
        if (!ignore) setError(e.message || 'Failed to load device status')
      } finally {
        if (!ignore) setLoading(false)
      }
    }
    load()
    return () => { ignore = true }
  }, [token])

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Device Online Status</h2>
        <p className="text-sm text-gray-500">
          All devices with current online / offline status and their linked numbers.
        </p>
      </div>

      {error && (
        <div className="p-3 rounded bg-red-100 text-red-700 text-sm">{error}</div>
      )}

      <div className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden">
        <div className="px-5 py-3 border-b dark:border-gray-800 flex items-center justify-between">
          <h3 className="text-lg font-medium">Devices</h3>
          {loading && <span className="text-xs text-gray-500">Loading...</span>}
        </div>
        <div className="divide-y dark:divide-gray-800">
          {items.length === 0 && !loading ? (
            <div className="px-5 py-4 text-sm text-gray-500">No devices found</div>
          ) : (
            items.map((d) => (
              <div key={d._id} className="px-5 py-4 space-y-3">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <div className="font-medium">
                      {d.deviceName || d.deviceUserName || 'Unnamed Device'}
                    </div>
                    <div className="text-xs text-gray-500">
                      Code: {d.deviceCode || '-'}
                    </div>
                    <div className="text-xs text-gray-500">
                      User: {d.owner ? `${d.owner.name || ''} (${d.owner.email || ''}) [${d.owner.role}]` : '-'}
                    </div>
                  </div>
                  <div className="text-right text-sm">
                    <span
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        d.online
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full mr-1 ${
                          d.online ? 'bg-green-500' : 'bg-gray-400'
                        }`}
                      />
                      {d.online ? 'Online' : 'Offline'}
                    </span>
                    <div className="text-[11px] text-gray-500 mt-1">
                      Last seen: {d.lastSeen ? new Date(d.lastSeen).toLocaleString() : 'N/A'}
                    </div>
                  </div>
                </div>

                <div className="mt-2">
                  <div className="text-xs font-semibold text-gray-600 mb-1">
                    Numbers on this device
                  </div>
                  {(!d.paymentMethods || d.paymentMethods.length === 0) ? (
                    <div className="text-xs text-gray-500">No numbers linked to this device</div>
                  ) : (
                    <div className="border rounded-md dark:border-gray-800 overflow-hidden">
                      <table className="min-w-full text-xs">
                        <thead className="bg-gray-50 dark:bg-gray-800">
                          <tr className="text-left">
                            <th className="px-3 py-2">Provider</th>
                            <th className="px-3 py-2">Number</th>
                            <th className="px-3 py-2">SIM</th>
                            <th className="px-3 py-2">Gateway</th>
                            <th className="px-3 py-2">Status</th>
                            <th className="px-3 py-2">Owner</th>
                          </tr>
                        </thead>
                        <tbody>
                          {d.paymentMethods.map((pm) => (
                            <tr key={pm._id} className="border-t dark:border-gray-800">
                              <td className="px-3 py-2 capitalize">{pm.provider}</td>
                              <td className="px-3 py-2 font-mono text-[11px]">{pm.accountNumber}</td>
                              <td className="px-3 py-2">SIM {pm.simIndex}</td>
                              <td className="px-3 py-2 capitalize">{pm.gateway}</td>
                              <td className="px-3 py-2">
                                <span
                                  className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-medium ${
                                    pm.status === 'active'
                                      ? 'bg-green-100 text-green-700'
                                      : 'bg-red-100 text-red-700'
                                  }`}
                                >
                                  {pm.status === 'active' ? 'Active' : 'Inactive'}
                                </span>
                              </td>
                              <td className="px-3 py-2">
                                {pm.owner ? (
                                  <span className="text-[11px]">
                                    {pm.owner.name || ''} ({pm.owner.email || ''}) [{pm.owner.role}]
                                  </span>
                                ) : (
                                  <span className="text-[11px] text-gray-500">-</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
