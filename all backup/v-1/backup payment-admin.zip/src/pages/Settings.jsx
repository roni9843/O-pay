import React from 'react'

export default function Settings(){
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Settings</h2>
        <p className="text-sm text-gray-500">Platform configuration.</p>
      </div>
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-5">
        <div className="text-sm text-gray-500">Coming soon.</div>
      </div>
    </div>
  )
}
