import React, { useEffect, useState } from 'react'
import { useAuthStore } from '../store/authStore'
import {
  listOpayBusinesses,
  createOpayBusiness,
  updateOpayBusiness,
  regenerateOpayBusinessToken,
} from '../lib/api'
import { Loader2, RefreshCw, Lock, Globe2, Mail, KeyRound } from 'lucide-react'

export default function OpayBusiness() {
  const token = useAuthStore((s) => s.token)
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [creating, setCreating] = useState(false)
  const [regenLoading, setRegenLoading] = useState({})
  const [copiedId, setCopiedId] = useState(null)

  const [form, setForm] = useState({
    name: '',
    domain: '',
    email: '',
    password: '',
    enabled: true,
  })

  const load = async () => {
    if (!token) return
    setLoading(true)
    setError('')
    try {
      const res = await listOpayBusinesses(token)
      setItems(res?.data || [])
    } catch (e) {
      setError(e.message || 'Failed to load Opay businesses')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [token])

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  const handleCreate = async (e) => {
    e.preventDefault()
    if (!token) return
    setCreating(true)
    setError('')
    try {
      const payload = {
        name: form.name,
        domain: form.domain,
        email: form.email,
        password: form.password,
        enabled: form.enabled,
      }
      const res = await createOpayBusiness(token, payload)
      const created = res?.data
      if (created) {
        setItems((prev) => [created, ...prev])
        setForm({ name: '', domain: '', email: '', password: '', enabled: true })
      }
    } catch (e) {
      setError(e.message || 'Failed to create brand')
    } finally {
      setCreating(false)
    }
  }

  const toggleEnabled = async (item) => {
    if (!token) return
    try {
      const res = await updateOpayBusiness(token, item._id, { enabled: !item.enabled })
      const updated = res?.data || item
      setItems((prev) => prev.map((b) => (b._id === updated._id ? updated : b)))
    } catch (e) {
      setError(e.message || 'Failed to update status')
    }
  }

  const handleRegenerate = async (item) => {
    if (!token) return
    if (!window.confirm('Are you sure you want to regenerate this API token? Old token will stop working.')) {
      return
    }
    setRegenLoading((prev) => ({ ...prev, [item._id]: true }))
    try {
      const res = await regenerateOpayBusinessToken(token, item._id)
      const updated = res?.data || item
      setItems((prev) => prev.map((b) => (b._id === updated._id ? updated : b)))
    } catch (e) {
      setError(e.message || 'Failed to regenerate token')
    } finally {
      setRegenLoading((prev) => ({ ...prev, [item._id]: false }))
    }
  }

  const handleCopyToken = async (item) => {
    if (!navigator.clipboard || !item?.apiToken) return
    try {
      await navigator.clipboard.writeText(item.apiToken)
      setCopiedId(item._id)
      setTimeout(() => {
        setCopiedId((prev) => (prev === item._id ? null : prev))
      }, 1500)
    } catch (e) {
      // ignore clipboard errors silently
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h2 className="text-xl font-semibold tracking-tight">Opay Business</h2>
        <p className="text-xs text-slate-400 max-w-xl">
          Create and manage Opay Business brands. Each brand has a unique domain, login email & password, enable/disable
          status, and its own API token.
        </p>
      </div>

      {error && (
        <div className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-4 py-2 text-xs text-rose-200">
          {error}
        </div>
      )}

      {/* Create form */}
      <form
        onSubmit={handleCreate}
        className="rounded-2xl border border-slate-800/80 bg-slate-900/70 p-5 shadow-inner shadow-black/40 space-y-4"
      >
        <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Globe2 className="w-4 h-4 text-violet-400" />
              Create New Brand
            </h3>
            <p className="text-[11px] text-slate-400">Domain must be unique. Brand will be enabled by default.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="space-y-1.5">
            <label className="block text-slate-300">Brand Name</label>
            <div className="relative">
              <span className="pointer-events-none absolute inset-y-0 left-2 flex items-center text-slate-500">
                <Globe2 className="w-3.5 h-3.5" />
              </span>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => handleChange('name', e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-950/70 px-7 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-violet-500"
                placeholder="My Brand"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-slate-300">Domain (unique)</label>
            <div className="relative">
              <span className="pointer-events-none absolute inset-y-0 left-2 flex items-center text-slate-500 text-[11px]">
                https://
              </span>
              <input
                type="text"
                required
                value={form.domain}
                onChange={(e) => handleChange('domain', e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-950/70 pl-14 pr-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-violet-500"
                placeholder="brand.example.com"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-slate-300">Login Email</label>
            <div className="relative">
              <span className="pointer-events-none absolute inset-y-0 left-2 flex items-center text-slate-500">
                <Mail className="w-3.5 h-3.5" />
              </span>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => handleChange('email', e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-950/70 px-7 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-violet-500"
                placeholder="brand@example.com"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-slate-300">Login Password</label>
            <div className="relative">
              <span className="pointer-events-none absolute inset-y-0 left-2 flex items-center text-slate-500">
                <Lock className="w-3.5 h-3.5" />
              </span>
              <input
                type="password"
                required
                value={form.password}
                onChange={(e) => handleChange('password', e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-950/70 px-7 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-violet-500"
                placeholder="••••••••"
              />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 pt-2 text-xs">
          <label className="inline-flex items-center gap-2 cursor-pointer select-none">
            <div
              className={`relative inline-flex h-5 w-9 items-center rounded-full border border-slate-600 transition-colors duration-200 ${
                form.enabled ? 'bg-violet-500/80 border-violet-400' : 'bg-slate-800'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-slate-950 shadow transition-transform duration-200 ${
                  form.enabled ? 'translate-x-4' : 'translate-x-0.5'
                }`}
              />
            </div>
            <span className="text-slate-200">Enabled</span>
          </label>

          <button
            type="submit"
            disabled={creating}
            className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-r from-violet-500 to-indigo-600 px-4 py-1.5 text-xs font-medium text-white shadow hover:shadow-violet-500/30 disabled:opacity-60"
          >
            {creating && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
            <span>Create Brand</span>
          </button>
        </div>
      </form>

      {/* List of brands */}
      <div className="rounded-2xl border border-slate-800/80 bg-slate-900/70 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
            <KeyRound className="w-4 h-4 text-violet-400" />
            <span>Existing Brands</span>
          </div>
          <button
            type="button"
            onClick={load}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 px-3 py-1 text-[11px] text-slate-200 hover:bg-slate-800 disabled:opacity-60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        {loading ? (
          <div className="py-6 text-xs text-slate-400 flex items-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin" /> Loading brands...
          </div>
        ) : items.length === 0 ? (
          <div className="py-6 text-xs text-slate-500">No brands created yet.</div>
        ) : (
          <div className="space-y-3 text-xs">
            {items.map((item) => (
              <div
                key={item._id}
                className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 rounded-xl border border-slate-800 bg-slate-950/60 px-3 py-3"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-semibold text-slate-100">{item.name}</span>
                    <span
                      className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ${
                        item.enabled
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/40'
                          : 'bg-slate-800 text-slate-300 border border-slate-600'
                      }`}
                    >
                      {item.enabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                  <div className="text-slate-400 flex flex-wrap gap-3">
                    <span className="flex items-center gap-1">
                      <Globe2 className="w-3.5 h-3.5" />
                      <span className="break-all">{item.domain}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Mail className="w-3.5 h-3.5" />
                      <span className="break-all">{item.email}</span>
                    </span>
                  </div>
                  <div className="mt-1 text-[11px] text-slate-400 flex flex-wrap gap-2">
                    <span className="font-medium text-slate-200">API Token:</span>
                    <button
                      type="button"
                      onClick={() => handleCopyToken(item)}
                      className="inline-flex items-center gap-1 font-mono break-all text-slate-200/90 hover:text-violet-300 underline-offset-2 hover:underline"
                    >
                      <span>{item.apiToken}</span>
                      {copiedId === item._id && <span className="text-emerald-300 text-[10px]">Copied</span>}
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-start md:self-center">
                  <button
                    type="button"
                    onClick={() => toggleEnabled(item)}
                    className="inline-flex items-center gap-1 rounded-md border border-slate-700 px-3 py-1 text-[11px] text-slate-200 hover:bg-slate-800"
                  >
                    {item.enabled ? 'Disable' : 'Enable'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRegenerate(item)}
                    disabled={regenLoading[item._id]}
                    className="inline-flex items-center gap-1 rounded-md bg-gradient-to-r from-violet-500 to-indigo-600 px-3 py-1 text-[11px] text-white hover:shadow-lg disabled:opacity-60"
                  >
                    {regenLoading[item._id] && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    <span>Regenerate Token</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
