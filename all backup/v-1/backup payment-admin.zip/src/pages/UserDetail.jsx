import React, { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useParams } from 'react-router-dom'
import { listUsers, addBalance, getSubscriptionPlans, purchaseUserSubscription, getUserSubscriptionsAdmin } from '../lib/api'
import { useAuthStore } from '../store/authStore'
import { User as UserIcon, Wallet, Activity, CalendarClock, Globe2, Loader2 } from 'lucide-react'

export default function UserDetail() {
  const { id } = useParams()
  const token = useAuthStore(s => s.token)
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [amount, setAmount] = useState('')
  const [mode, setMode] = useState('inc')
  const [saving, setSaving] = useState(false)
  const [actionError, setActionError] = useState('')
  const [plans, setPlans] = useState([])
  const [plansLoading, setPlansLoading] = useState(true)
  const [userSubs, setUserSubs] = useState([])
  const [subForm, setSubForm] = useState({ planId: '', durationMonths: 1, domain: '' })
  const [subSaving, setSubSaving] = useState(false)
  const [subError, setSubError] = useState('')

  useEffect(() => {
    let ignore = false

    async function loadUser() {
      if (!token) return
      setLoading(true)
      setError('')
      try {
        const res = await listUsers(token, { page: 1, limit: 200 })
        const found = (res.data || []).find(u => u._id === id)
        if (!ignore) {
          setUser(found || null)
          if (!found) setError('User not found in the system')
        }
      } catch (e) {
        if (!ignore) setError(e.message || 'Failed to load user details')
      } finally {
        if (!ignore) setLoading(false)
      }
    }

    async function loadPlans() {
      try {
        setPlansLoading(true)
        const res = await getSubscriptionPlans()
        if (!ignore) setPlans(res || [])
      } catch (e) {
        // silent fail or log
      } finally {
        if (!ignore) setPlansLoading(false)
      }
    }

    async function loadUserSubs() {
      if (!token) return
      try {
        const res = await getUserSubscriptionsAdmin(token, id)
        if (!ignore) setUserSubs(res.data || [])
      } catch (e) {
        // optional: log admin subscription fetch error
      }
    }

    loadUser()
    loadPlans()
    loadUserSubs()

    return () => { ignore = true }
  }, [id, token])

  async function submit(e) {
    e.preventDefault()
    setActionError('')
    const num = Number(amount)
    if (!Number.isFinite(num) || num === 0) {
      setActionError('Please enter a valid amount')
      return
    }
    try {
      setSaving(true)
      await addBalance(token, id, num, mode === 'set' ? 'set' : undefined)

      // refresh
      const res = await listUsers(token, { page: 1, limit: 200 })
      const found = (res.data || []).find(u => u._id === id)
      if (found) setUser(found)
      setAmount('')
    } catch (err) {
      setActionError(err.message || 'Balance update failed')
    } finally {
      setSaving(false)
    }
  }

  async function handlePurchaseSubscription(e) {
    e.preventDefault()
    setSubError('')
    if (!subForm.planId || !subForm.domain.trim()) {
      setSubError('Please select a plan and enter a domain')
      return
    }
    try {
      setSubSaving(true)
      await purchaseUserSubscription(token, id, {
        planId: subForm.planId,
        durationMonths: Number(subForm.durationMonths) || 1,
        domain: subForm.domain.trim(),
      })

      // refresh user
      const res = await listUsers(token, { page: 1, limit: 200 })
      const found = (res.data || []).find(u => u._id === id)
      if (found) setUser(found)
      setSubForm({ planId: '', durationMonths: 1, domain: '' })
    } catch (err) {
      setSubError(err.message || 'Failed to assign subscription')
    } finally {
      setSubSaving(false)
    }
  }

  const subscription = user?.subscription
  let daysLeft = null
  let isExpired = false
  if (subscription?.endDate) {
    const end = new Date(subscription.endDate)
    const diff = end.getTime() - Date.now()
    isExpired = diff <= 0
    daysLeft = isExpired ? 0 : Math.ceil(diff / (1000 * 60 * 60 * 24))
  }

  const subsByPlanId = new Map()
  if (Array.isArray(userSubs)) {
    userSubs.forEach(sub => {
      const rawPlanId = sub.plan && (sub.plan._id || sub.plan)
      if (!rawPlanId || !sub.endDate) return
      const planId = String(rawPlanId)
      const existing = subsByPlanId.get(planId)
      const end = new Date(sub.endDate)
      if (!existing || end > new Date(existing.endDate)) {
        subsByPlanId.set(planId, sub)
      }
    })
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-indigo-950 via-purple-950 to-fuchsia-950 pb-12">
      {/* Animated background glows */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-40 h-96 w-96 animate-pulse-slow rounded-full bg-gradient-radial from-violet-600/25 to-transparent blur-3xl" />
        <div className="absolute top-10 right-0 h-80 w-80 animate-pulse-slow-delay rounded-full bg-gradient-radial from-cyan-500/20 to-transparent blur-3xl" />
        <div className="absolute -bottom-40 -right-20 h-96 w-96 animate-pulse-slow-2 rounded-full bg-gradient-radial from-pink-500/15 to-transparent blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 pt-8 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <motion.div
              animate={{ scale: [1, 1.12, 1] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="h-12 w-12 rounded-2xl bg-gradient-to-br from-violet-600 to-fuchsia-700 flex items-center justify-center shadow-lg"
            >
              <UserIcon className="h-6 w-6 text-white" />
            </motion.div>
            <div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-violet-300 via-fuchsia-300 to-cyan-200 bg-clip-text text-transparent">
                {user?.name || 'User Profile'}
              </h2>
              <p className="text-slate-400 mt-1">Manage balance • subscription • access</p>
            </div>
          </div>
        </motion.div>

        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="rounded-2xl bg-red-950/40 border border-red-400/30 backdrop-blur-xl p-4 text-red-200 shadow-xl"
          >
            {error}
          </motion.div>
        )}

        <AnimatePresence>
          {loading ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 p-8 flex items-center justify-center min-h-[300px]"
            >
              <div className="flex items-center gap-3 text-violet-300">
                <Loader2 className="h-6 w-6 animate-spin" />
                <span>Loading user data...</span>
              </div>
            </motion.div>
          ) : user ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid gap-6 lg:grid-cols-3"
            >
              {/* User Info Card */}
              <div className="lg:col-span-2 space-y-6">
                <div className="rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl overflow-hidden">
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-white mb-5 flex items-center gap-3">
                      <Activity className="h-5 w-5 text-emerald-400" />
                      Profile Overview
                    </h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <InfoItem label="Email" value={user.email} mono />
                      <InfoItem label="Role" value={user.role} badge role={user.role} />
                      <InfoItem label="Balance" value={`৳${(user.balance ?? 0).toFixed(2)}`} accent="emerald" />
                      <InfoItem label="Verified Volume" value={`৳${(user.verifiedAmount ?? 0).toFixed(2)}`} accent="violet" />
                      <InfoItem label="Devices" value={user.devicesCount ?? 0} />
                      <InfoItem label="Verified Payments" value={user.verifiedPayments ?? 0} />
                    </div>

                    {subscription && (
                      <div className="mt-6 pt-6 border-t border-white/10">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <CalendarClock className="h-5 w-5 text-sky-400" />
                            <div>
                              <h4 className="text-lg font-semibold text-white">{subscription.planName}</h4>
                              <p className="text-sm text-slate-400">
                                Valid until {new Date(subscription.endDate).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          <div className={`px-4 py-2 rounded-full text-sm font-medium border ${isExpired
                            ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                            : 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                            }`}>
                            {isExpired ? 'Expired' : `${daysLeft} day${daysLeft === 1 ? '' : 's'} left`}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Balance Edit */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl p-6"
                >
                  <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <Wallet className="h-5 w-5 text-emerald-400" />
                    Adjust Balance
                  </h4>

                  <form onSubmit={submit} className="flex flex-wrap items-end gap-4">
                    <div className="flex-1 min-w-[180px]">
                      <label className="block text-sm text-slate-300 mb-2">Amount</label>
                      <input
                        type="number"
                        step="0.01"
                        value={amount}
                        onChange={e => setAmount(e.target.value)}
                        placeholder={mode === 'set' ? "New balance" : "Amount to add/subtract"}
                        className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-400/50 backdrop-blur-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-slate-300 mb-2">Mode</label>
                      <select
                        value={mode}
                        onChange={e => setMode(e.target.value)}
                        className="px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white focus:outline-none focus:border-emerald-400/50 backdrop-blur-sm"
                      >
                        <option value="inc">Add / Subtract</option>
                        <option value="set">Set Exact</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={saving || !amount}
                      className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-medium shadow-lg disabled:opacity-50 min-w-[140px]"
                    >
                      {saving ? (
                        <span className="flex items-center gap-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Saving...
                        </span>
                      ) : 'Update Balance'}
                    </button>
                  </form>

                  {actionError && (
                    <p className="mt-3 text-red-400 text-sm">{actionError}</p>
                  )}
                </motion.div>
              </div>

              {/* Subscription Actions */}
              <div className="space-y-6">
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 }}
                  className="rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl p-6"
                >
                  <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <Globe2 className="h-5 w-5 text-sky-400" />
                    Assign Subscription
                  </h4>

                  <form onSubmit={handlePurchaseSubscription} className="space-y-5">
                    <div>
                      <label className="block text-sm text-slate-300 mb-2">Plan</label>
                      <select
                        value={subForm.planId}
                        onChange={e => setSubForm(f => ({ ...f, planId: e.target.value }))}
                        disabled={plansLoading || plans.length === 0}
                        className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white focus:outline-none focus:border-sky-400/50 backdrop-blur-sm"
                      >
                        <option value="">Choose Plan</option>
                        {plans.map(p => (
                          <option key={p._id} value={p._id}>{p.name}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm text-slate-300 mb-2">Months</label>
                        <select
                          value={subForm.durationMonths}
                          onChange={e => setSubForm(f => ({ ...f, durationMonths: e.target.value }))}
                          className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white focus:outline-none focus:border-sky-400/50 backdrop-blur-sm"
                        >
                          <option value={1}>1 Month</option>
                          <option value={6}>6 Months</option>
                          <option value={12}>12 Months</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm text-slate-300 mb-2">Domain</label>
                        <input
                          type="text"
                          value={subForm.domain}
                          onChange={e => setSubForm(f => ({ ...f, domain: e.target.value }))}
                          placeholder="yourdomain.com"
                          className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-slate-500 focus:outline-none focus:border-sky-400/50 backdrop-blur-sm"
                        />
                      </div>
                    </div>

                    {subError && <p className="text-red-400 text-sm">{subError}</p>}

                    <button
                      type="submit"
                      disabled={subSaving || !subForm.planId || !subForm.domain}
                      className="w-full py-3 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-500 to-fuchsia-500 text-white font-medium shadow-lg disabled:opacity-50"
                    >
                      {subSaving ? (
                        <span className="flex items-center justify-center gap-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Processing...
                        </span>
                      ) : 'Assign Subscription'}
                    </button>
                  </form>
                </motion.div>

                {/* Plans Overview */}
                {plans.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 }}
                    className="rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 shadow-2xl p-6"
                  >
                    <h4 className="text-lg font-semibold text-white mb-4">Available Plans</h4>

                    <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                    
                      {plans.map(plan => {
                        const activeSub = subsByPlanId.get(String(plan._id))
                        let planDaysLeft = null
                        let planExpired = false
                        let planEndDate = null

                        if (activeSub && activeSub.endDate) {
                          planEndDate = activeSub.endDate
                          const end = new Date(activeSub.endDate)
                          const diff = end.getTime() - Date.now()
                          planExpired = diff <= 0
                          planDaysLeft = planExpired ? 0 : Math.ceil(diff / (1000 * 60 * 60 * 24))
                        }

                        return (
                          <PlanCard
                            key={plan._id}
                            plan={plan}
                            isCurrent={!!activeSub}
                            daysLeft={planDaysLeft}
                            isExpired={planExpired}
                            endDate={planEndDate}
                          />
                        )
                      })}
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          ) : (
            <div className="rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 p-12 text-center text-slate-400">
              No user data available
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

function InfoItem({ label, value, mono = false, accent, badge, role }) {
  let className = "text-white font-medium"
  if (accent === 'emerald') className = "text-emerald-400 font-semibold"
  if (accent === 'violet') className = "text-violet-400 font-semibold"

  return (
    <div className="space-y-1">
      <div className="text-xs uppercase tracking-wide text-slate-400">{label}</div>
      {badge ? (
        <span
          className={`inline-flex px-3 py-1 rounded-full text-sm font-medium border ${
            role === 'admin' ? 'bg-rose-950/50 border-rose-500/40 text-rose-300' :
              role === 'wallet_agent' ? 'bg-amber-950/50 border-amber-500/40 text-amber-300' :
                'bg-emerald-950/50 border-emerald-500/40 text-emerald-300'
          }`}
        >
          {value}
        </span>
      ) : (
        <div className={`${mono ? 'font-mono' : ''} ${className}`}>
          {value}
        </div>
      )}
    </div>
  )
}

function PlanCard({ plan, isCurrent = false, daysLeft = null, isExpired = false, endDate }) {
  if (!plan) return null

  const colorMap = {
    green: { border: 'border-emerald-500/40', bg: 'bg-emerald-950/30', text: 'text-emerald-300' },
    blue: { border: 'border-sky-500/40', bg: 'bg-sky-950/30', text: 'text-sky-300' },
    red: { border: 'border-rose-500/40', bg: 'bg-rose-950/30', text: 'text-rose-300' },
  }

  const colors = colorMap[plan.color] || colorMap.blue
  const formattedEndDate = endDate ? new Date(endDate).toLocaleDateString() : null

  return (
    <div className={`rounded-2xl border ${colors.border} ${colors.bg} p-5 transition-all hover:border-white/30`}>
      <div className="flex items-center justify-between mb-3">
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${colors.bg} ${colors.text}`}>
          {plan.name}
        </span>
        <div className="text-right space-y-1">
          <div className="text-lg font-bold text-white">
            ৳{plan.pricing?.monthly?.toLocaleString() ?? '—'}
            <span className="text-sm font-normal text-slate-400"> / mo</span>
          </div>

           
          {isCurrent && (
            <>
              <div className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium border ${isExpired
                ? 'bg-rose-950/60 border-rose-500/50 text-rose-200'
                : 'bg-emerald-950/60 border-emerald-500/50 text-emerald-200'
              }`}>
                {isExpired ? 'Expired' : `${daysLeft ?? 0} day${daysLeft === 1 ? '' : 's'} left`}
              </div>
              
              {formattedEndDate && (
                <div className="text-[11px] text-slate-100 font-medium">
                  Subscription ends on {formattedEndDate}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="space-y-2 text-sm text-slate-300">
        {plan.pricing?.sixMonths?.price && (
          <div>6 months: <span className="font-semibold text-white">৳{plan.pricing.sixMonths.price.toLocaleString()}</span></div>
        )}
        {plan.pricing?.yearly?.price && (
          <div>Yearly: <span className="font-semibold text-white">৳{plan.pricing.yearly.price.toLocaleString()}</span></div>
        )}
      </div>

      <div className="mt-4 pt-4 border-t border-white/10 space-y-1.5 text-sm">
        <FeatureLine label="Domains" value={plan.features?.domain} />
        <FeatureLine label="Devices" value={plan.features?.devices} />
        <FeatureLine label="SIM numbers" value={plan.features?.simNumbers} />
        <FeatureLine label="Brands" value={plan.features?.brand} />
        {plan.features?.paymentMethods?.length > 0 && (
          <FeatureLine label="Methods" value={plan.features.paymentMethods.join(', ')} />
        )}
        {!isCurrent && (
          <div className="text-[11px] text-slate-400 mt-1">Not active for this user.</div>
        )}
      </div>
    </div>
  )
}

function FeatureLine({ label, value }) {
  return (
    <div className="flex justify-between">
      <span className="text-slate-400">{label}:</span>
      <span className="font-medium text-white">{value ?? '—'}</span>
    </div>
  )
}