import React, { useEffect, useState } from 'react'
import { useAuthStore } from '../store/authStore'

export default function PendingBalances(){
  const token = useAuthStore(s=>s.token)
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function load(){
    if (!token) return
    setLoading(true); setError('')
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}/api/balance-topups/pending?page=1&limit=50`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data?.message || 'Failed to load')
      setItems(data.data || [])
    } catch(e){
      setError(e.message || 'Failed to load')
    } finally {
      setLoading(false)
    }
  }

  async function approve(id){
    if (!token) return
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}/api/balance-topups/approve/${id}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data?.message || 'Approve failed')
      await load()
    } catch(e){
      alert(e.message)
    }
  }

  useEffect(()=>{ load() }, [token])

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Balance Pending</h2>
        <p className="text-sm text-gray-500">Review and approve user balance top-ups.</p>
      </div>
      {error && <div className="p-3 rounded bg-red-100 text-red-700">{error}</div>}
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden">
        <div className="px-5 py-3 border-b dark:border-gray-800">
          <h3 className="text-lg font-medium">Pending Requests</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b dark:border-gray-800">
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Amount</th>
                <th className="px-4 py-3">Screenshot</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td className="px-4 py-3" colSpan={5}>Loading...</td></tr>
              ) : items.length === 0 ? (
                <tr><td className="px-4 py-3" colSpan={5}>No pending requests</td></tr>
              ) : (
                items.map(it => (
                  <tr key={it._id} className="border-b dark:border-gray-800">
                    <td className="px-4 py-3">{it.user?.name || '-'}</td>
                    <td className="px-4 py-3">{it.user?.email || '-'}</td>
                    <td className="px-4 py-3 font-semibold">${Number(it.amount).toFixed(2)}</td>
                    <td className="px-4 py-3">
                      {it.screenshotUrl ? (
                        <a href={`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}${it.screenshotUrl}`} target="_blank" rel="noreferrer" className="text-blue-600">View</a>
                      ) : '-' }
                    </td>
                    <td className="px-4 py-3">
                      <button className="px-3 py-2 rounded bg-green-600 text-white hover:bg-green-700" onClick={()=>approve(it._id)}>Approve</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
