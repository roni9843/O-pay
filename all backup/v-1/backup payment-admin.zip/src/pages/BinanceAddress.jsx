import React, { useEffect, useState } from 'react'
import { useAuthStore } from '../store/authStore'

export default function BinanceAddress(){
  const token = useAuthStore(s=>s.token)
  const [address, setAddress] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    async function load(){
      try {
        const res = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}/api/settings/binance-address`)
        const data = await res.json()
        if (res.ok) setAddress(data.address || '')
      } catch (_) {}
    }
    load()
  }, [])

  async function save(){
    if (!token) return
    setLoading(true); setError(''); setSaved(false)
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:5000'}/api/settings/binance-address`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ address })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data?.message || 'Save failed')
      setSaved(true)
      setTimeout(()=>setSaved(false), 2000)
    } catch(e){
      setError(e.message || 'Save failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Binance Address</h2>
        <p className="text-sm text-gray-500">Set the address users will send funds to.</p>
      </div>
      {error && <div className="p-3 rounded bg-red-100 text-red-700">{error}</div>}
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow p-5 space-y-3">
        <label className="text-sm text-gray-500">Address</label>
        <input
          value={address}
          onChange={e=>setAddress(e.target.value)}
          className="px-3 py-2 rounded border dark:bg-gray-800 dark:border-gray-700"
          placeholder="Enter Binance address"
        />
        <button disabled={loading} onClick={save} className="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-60">
          {loading ? 'Saving...' : 'Save'}
        </button>
        {saved && <div className="text-sm text-green-600">Saved</div>}
      </div>
    </div>
  )
}
